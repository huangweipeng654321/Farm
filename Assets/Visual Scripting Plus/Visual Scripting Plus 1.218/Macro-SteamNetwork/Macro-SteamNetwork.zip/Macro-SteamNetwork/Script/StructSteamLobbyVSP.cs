using System.Collections.Generic;

public struct SteamLobbyVSP
{
    public int MaxPlayers;
    public string Slots;
    public string ID;
    public string Name;
    public string Password;
    public string HostId;
    public string SubHostId;
    public string isPrivate;
    public string CanHostReconnect;
    public string Search_GameMode;
    public string Search_ExtraMode;
    public string Search_RankMin;
    public string Search_RankMax;
    public string Search_LevelMin;
    public string Search_LevelMax;
    public string Search_ExtraNumber;
    public string Search_Region;
    public string isLocked;
    public List<string> Members;
    public List<string> Clients;
    public List<string> ClientsConnected;
    public List<SteamUserVSP> SteamUsers;
}
