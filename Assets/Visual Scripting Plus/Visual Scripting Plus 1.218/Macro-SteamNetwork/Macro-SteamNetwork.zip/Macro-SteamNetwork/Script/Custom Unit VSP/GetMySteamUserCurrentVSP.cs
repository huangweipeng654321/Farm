using Unity.VisualScripting;
using UnityEngine;

[UnitTitle("Steam : Get Steam Info of Member in Lobby")]
[UnitCategory("Custom/Visual Scripting Plus")]
[UnitSubtitle("Call this to see Member info")]
public class GetMySteamUserInfoVSP : Unit
{
    // Flow ports
    private ControlInput enter;
    private ControlOutput exit;

    // Value ports
    private ValueOutput userOutput;
    private ValueInput SteamID;
    protected override void Definition()
    {
        // GameObject input
        SteamID = ValueInput<string>("Steam ID"," ");
        
        // Flow input & output
        enter = ControlInput(" ", (flow) =>
        {
            GameObject go = GameObject.Find("Macro-SteamNetwork");
            SteamUserVSP result = default;
            string id = flow.GetValue<string>(SteamID);

            if (go != null)
            {
                var comp = go.GetComponent<SteamNetworkVSP>();
                if (comp != null)
                {
                    result = comp.GetSteamMemberInfo(id);
                }
            }

            flow.SetValue(userOutput, result);
            return exit;
        }); 

        exit = ControlOutput("  ");


        // Output: aSteamUserPlus
        userOutput = ValueOutput<SteamUserVSP>("Steam User ");

        Succession(enter, exit);
        Requirement(SteamID, enter);
        Assignment(enter, userOutput);
    }
}
