using Unity.VisualScripting;
using UnityEngine;

[UnitTitle("Get A Steam User Plus info")]
[UnitCategory("Custom/Visual Scripting Plus")]
public class ASteamUserPlusTypeVSP : Unit
{
    // Input ports
    private ValueInput aSteamUserPlus;

    // Output port
    private ValueOutput SteamID;
    private ValueOutput SteamName;
    private ValueOutput SteamLevel;
    private ValueOutput isOnline;
    private ValueOutput SteamAvatar;
    protected override void Definition()
    {
        //  Input
        aSteamUserPlus = ValueInput<SteamUserPlusVSP>("Steam User Plus");

        //  Output
        SteamID = ValueOutput<string>("Steam ID", (flow) =>
        {
            string val1 = flow.GetValue<SteamUserPlusVSP>(aSteamUserPlus).Steam_Id;
            return val1;
        });

        SteamName = ValueOutput<string>("Steam Name", (flow) =>
        {
            string val2 = flow.GetValue<SteamUserPlusVSP>(aSteamUserPlus).Steam_Name;
            return val2;
        });

        SteamLevel = ValueOutput<int>("Steam Level", (flow) =>
        {
            int val3 = flow.GetValue<SteamUserPlusVSP>(aSteamUserPlus).Steam_Level;
            return val3;
        });

        isOnline = ValueOutput<bool>("is Online", (flow) =>
        {
            bool val4 = flow.GetValue<SteamUserPlusVSP>(aSteamUserPlus).Steam_IsOnline;
            return val4;
        });

        SteamAvatar = ValueOutput<Texture2D>("Steam Avatar", (flow) =>
        {
            Texture2D val5 = flow.GetValue<SteamUserPlusVSP>(aSteamUserPlus).Steam_Avatar;
            return val5;
        });
    }
}
