using Steamworks.Data;
using Unity.VisualScripting;
using UnityEngine;

[UnitTitle("Steam : Get Current Lobby")]
[UnitCategory("Custom/Visual Scripting Plus")]
[UnitSubtitle(". Get current joined Lobby")]
public class GetSteamLobbyCurrentVSP : Unit
{
    // Flow ports
    private ControlInput enter;
    private ControlOutput exit;

    // Value ports
    private ValueOutput userOutput;     

    protected override void Definition()
    {
        // Flow input & output
        enter = ControlInput(" ", (flow) =>
        {
            GameObject go = GameObject.Find("Macro-SteamNetwork");
            SteamLobbyVSP result = default; //class

            if (go != null)
            {
                var comp = go.GetComponent<SteamNetworkVSP>();
                if (comp != null)
                {
                    result = comp.GetCurrentLobbyInfo();
                }
            }

            flow.SetValue(userOutput, result);
            return exit;
        }); 

        exit = ControlOutput("  ");


        // Output: 
        userOutput = ValueOutput<SteamLobbyVSP>("A Lobby"); //class

        Succession(enter, exit);
        Assignment(enter, userOutput);
    }
}
