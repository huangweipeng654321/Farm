using Unity.VisualScripting;

[UnitTitle("Get A Lobby Steam ID info")]
[UnitCategory("Custom/Visual Scripting Plus")]
public class ALobbyTypeSteamShortVSP : Unit
{
    // Input ports
    private ValueInput aSteamLobby;

    // Output port
    private ValueOutput LobbyID;
    private ValueOutput isLocked;
    protected override void Definition()
    {
        //  Input
        aSteamLobby = ValueInput<SteamLobbyVSP>("A Lobby");

        LobbyID = ValueOutput<string>("Lobby ID", (flow) =>
        {
            string val7 = flow.GetValue<SteamLobbyVSP>(aSteamLobby).ID;
            return val7;
        });

        isLocked = ValueOutput<bool>("is Locked", (flow) =>
        {
            bool val2 = bool.Parse(flow.GetValue<SteamLobbyVSP>(aSteamLobby).isLocked);
            return val2;
        });

    }
}
