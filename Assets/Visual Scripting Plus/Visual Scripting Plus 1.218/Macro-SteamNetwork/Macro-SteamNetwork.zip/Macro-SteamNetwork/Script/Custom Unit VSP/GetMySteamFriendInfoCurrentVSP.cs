using Unity.VisualScripting;
using UnityEngine;

[UnitTitle("Steam : My Friend Info")]
[UnitCategory("Custom/Visual Scripting Plus")]
[UnitSubtitle(". Steam User Info with Avatar\r\n. Call anytime when Steam is ready")]
public class GetMySteamFriendInfoCurrentVSP : Unit
{
    // Flow ports
    private ControlInput enter;
    private ControlOutput exit;

    // Value ports
    private ValueOutput userOutput;
    private ValueInput FriendSteamID;
    private ValueInput sizeInput;
    protected override void Definition()
    {
        // GameObject input
        FriendSteamID = ValueInput<string>("Friend Steam ID"," ");
        sizeInput = ValueInput<SteamAvatarSizeVSP>("Avatar Size", SteamAvatarSizeVSP.Small);

        // Flow input & output
        enter = ControlInput(" ", (flow) =>
        {
            GameObject go = GameObject.Find("Macro-SteamNetwork");
            SteamUserPlusVSP result = default; //class
            string id = flow.GetValue<string>(FriendSteamID);

            if (go != null)
            {
                var comp = go.GetComponent<SteamNetworkVSP>();
                if (comp != null)
                {
                    var sizeSelect = flow.GetValue<SteamAvatarSizeVSP>(sizeInput);
                    result = comp.GetFriendAvatarAndInfo(id, sizeSelect);
                }
            }
             
            flow.SetValue(userOutput, result);
            return exit;
        }); 

        exit = ControlOutput("  ");


        // Output: aSteamUserPlus
        userOutput = ValueOutput<SteamUserPlusVSP>("Steam User Plus"); //class

        Succession(enter, exit);
        Requirement(FriendSteamID, enter);
        Requirement(sizeInput, enter);
        Assignment(enter, userOutput);
    }
}
