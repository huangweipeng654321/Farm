using Unity.VisualScripting;

[UnitTitle("Get A Steam User info")]
[UnitCategory("Custom/Visual Scripting Plus")]
public class ASteamUserTypeVSP : Unit
{
    // Input ports
    private ValueInput aSteamUser;

    // Output port
    private ValueOutput SteamID;
    private ValueOutput SteamName;
    private ValueOutput SteamLevel;
    private ValueOutput isMe;
    private ValueOutput isOnline;
    private ValueOutput isFriend;
    protected override void Definition()
    {
        //  Input
        aSteamUser = ValueInput<SteamUserVSP>("Steam User");

        //  Output
        SteamID = ValueOutput<string>("Steam ID", (flow) =>
        {
            string val1 = flow.GetValue<SteamUserVSP>(aSteamUser).Steam_Id;
            return val1;
        });

        SteamName = ValueOutput<string>("Steam Name", (flow) =>
        {
            string val2 = flow.GetValue<SteamUserVSP>(aSteamUser).Steam_Name;
            return val2;
        });

        SteamLevel = ValueOutput<int>("Steam Level", (flow) =>
        {
            int val3 = flow.GetValue<SteamUserVSP>(aSteamUser).Steam_Level;
            return val3;
        });

        isMe = ValueOutput<bool>("is Me", (flow) =>
        {
            bool val4 = flow.GetValue<SteamUserVSP>(aSteamUser).Steam_IsMe;
            return val4;
        });

        isOnline = ValueOutput<bool>("is Online", (flow) =>
        {
            bool val5 = flow.GetValue<SteamUserVSP>(aSteamUser).Steam_IsOnline;
            return val5;
        });

        isFriend = ValueOutput<bool>("is Friend", (flow) =>
        {
            bool val6 = flow.GetValue<SteamUserVSP>(aSteamUser).Steam_IsFriend;
            return val6;
        });
    }
}
