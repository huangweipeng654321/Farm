using Unity.VisualScripting;
using UnityEngine;

[UnitTitle("Steam : My Steam Plus Info")]
[UnitCategory("Custom/Visual Scripting Plus")]
[UnitSubtitle(". Steam User Info with Avatar\r\n. Can call anytime whem Steam is ready")]
public class GetMySteamUserInfoCurrentVSP : Unit
{
    // Flow ports
    private ControlInput enter;
    private ControlOutput exit;

    // Value ports
    private ValueOutput userOutput;       // aSteamUserPlus output

    protected override void Definition()
    {
        // Flow input & output
        enter = ControlInput(" ", (flow) =>
        {
            GameObject go = GameObject.Find("Macro-SteamNetwork");
            SteamUserPlusVSP result = default;

            if (go != null)
            {
                var comp = go.GetComponent<SteamNetworkVSP>();
                if (comp != null)
                {
                    result = comp.GetMeAvatarAndInfo();
                }
            }

            flow.SetValue(userOutput, result);
            return exit;
        }); 

        exit = ControlOutput("  ");


        // Output: aSteamUserPlus
        userOutput = ValueOutput<SteamUserPlusVSP>("Steam User Plus");

        Succession(enter, exit);
        Assignment(enter, userOutput);
    }
}
