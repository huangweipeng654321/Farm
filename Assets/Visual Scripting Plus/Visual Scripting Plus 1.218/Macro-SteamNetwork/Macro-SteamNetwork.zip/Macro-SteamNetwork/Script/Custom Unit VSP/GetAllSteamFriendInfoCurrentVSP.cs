using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

[UnitTitle("Steam : All Friend Info")]
[UnitCategory("Custom/Visual Scripting Plus")]
[UnitSubtitle(". Steam User Info with Avatar\r\n. Call anytime when Steam is ready")]
public class GetAllSteamFriendInfoCurrentVSP : Unit
{
    // Flow ports
    private ControlInput enter;
    private ControlOutput exit;

    // Value ports
    private ValueOutput userOutput;
    private ValueInput sizeInput;
    protected override void Definition()
    {
        // GameObject input
        sizeInput = ValueInput<SteamAvatarSizeVSP>("Avatar Size", SteamAvatarSizeVSP.Small);

        // Flow input & output
        enter = ControlInput(" ", (flow) =>
        {
            GameObject go = GameObject.Find("Macro-SteamNetwork");
            List<SteamUserPlusVSP> result = default; //class

            if (go != null)
            {
                var comp = go.GetComponent<SteamNetworkVSP>();
                if (comp != null)
                {
                    var sizeSelect = flow.GetValue<SteamAvatarSizeVSP>(sizeInput);
                    result = comp.GetAllFriendAvatarAndInfo(sizeSelect);
                }
            }
             
            flow.SetValue(userOutput, result);
            return exit;
        }); 

        exit = ControlOutput("  ");


        // Output:
        userOutput = ValueOutput<List<SteamUserPlusVSP>>("Steam User Plus List"); //class

        Succession(enter, exit);
        Requirement(sizeInput, enter);
        Assignment(enter, userOutput);
    }
}
