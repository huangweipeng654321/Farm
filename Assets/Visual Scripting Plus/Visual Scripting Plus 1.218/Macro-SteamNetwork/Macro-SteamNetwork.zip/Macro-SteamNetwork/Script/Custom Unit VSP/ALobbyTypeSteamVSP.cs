using System.Collections.Generic;
using Unity.VisualScripting;

[UnitTitle("Get A Lobby steam info")]
[UnitCategory("Custom/Visual Scripting Plus")]
public class ALobbyTypeSteamVSP : Unit
{
    // Input ports
    private ValueInput aSteamLobby;

    // Output port
    private ValueOutput CanHostReconnect;
    private ValueOutput isPrivate;
    private ValueOutput isLocked;
    private ValueOutput MaxPlayers;
    private ValueOutput AvailableSlots;
    private ValueOutput HostID;
    private ValueOutput LobbyID;
    private ValueOutput Password;
    private ValueOutput SteamUsers;
    private ValueOutput MembersSteamID;
    private ValueOutput MembersClientID;
    private ValueOutput ConnectedClientID;
    private ValueOutput SearchRegion;
    private ValueOutput SearchLobbyName;
    private ValueOutput SearchGameMode;
    private ValueOutput SearchExtraMode;
    private ValueOutput SearchRankMin;
    private ValueOutput SearchRankMax;
    private ValueOutput SearchLevelMin;
    private ValueOutput SearchLevelMax;
    private ValueOutput SearchExtraNumber;
    protected override void Definition()
    {
        //  Input
        aSteamLobby = ValueInput<SteamLobbyVSP>("A Lobby");

        //  Output
        CanHostReconnect = ValueOutput<bool>("Can Host Reconnect", (flow) =>
        {
            bool val1 = bool.Parse(flow.GetValue<SteamLobbyVSP>(aSteamLobby).CanHostReconnect);
            return val1;
        });

        isPrivate = ValueOutput<bool>("is Private", (flow) =>
        {
            bool val2 = bool.Parse(flow.GetValue<SteamLobbyVSP>(aSteamLobby).isPrivate);
            return val2;
        });

        isLocked = ValueOutput<bool>("is Locked", (flow) =>
        {
            bool val3 = bool.Parse(flow.GetValue<SteamLobbyVSP>(aSteamLobby).isLocked);
            return val3;
        });

        MaxPlayers = ValueOutput<int>("Max Players", (flow) =>
        {
            int val4 = flow.GetValue<SteamLobbyVSP>(aSteamLobby).MaxPlayers;
            return val4;
        });

        AvailableSlots = ValueOutput<int>("Available Slots", (flow) =>
        {
            int val5 = int.Parse(flow.GetValue<SteamLobbyVSP>(aSteamLobby).Slots);
            return val5;
        });

        HostID = ValueOutput<string>("Host ID", (flow) =>
        {
            string val6 = flow.GetValue<SteamLobbyVSP>(aSteamLobby).HostId;
            return val6;
        });

        LobbyID = ValueOutput<string>("Lobby ID", (flow) =>
        {
            string val7 = flow.GetValue<SteamLobbyVSP>(aSteamLobby).ID;
            return val7;
        });

        Password = ValueOutput<string>("Password", (flow) =>
        {
            string val8 = flow.GetValue<SteamLobbyVSP>(aSteamLobby).Password;
            return val8;
        });

        SteamUsers = ValueOutput<List<SteamUserVSP>>("Steam Users", (flow) =>
        {
            var membersList1 = flow.GetValue<SteamLobbyVSP>(aSteamLobby);
            return membersList1.SteamUsers;
        });

        MembersSteamID = ValueOutput<List<string>>("Members Steam ID", (flow) =>
        {
            var membersList2 = flow.GetValue<SteamLobbyVSP>(aSteamLobby);
            return membersList2.Members;
        });

        MembersClientID = ValueOutput<List<string>>("Members Client ID", (flow) =>
        {
            var membersList3 = flow.GetValue<SteamLobbyVSP>(aSteamLobby);
            return membersList3.Clients;
        });

        ConnectedClientID = ValueOutput<List<string>>("Connected Client ID", (flow) =>
        {
            var membersList4 = flow.GetValue<SteamLobbyVSP>(aSteamLobby);
            return membersList4.ClientsConnected;
        });

        SearchRegion = ValueOutput<string>("Search Region", (flow) =>
        {
            string val9 = flow.GetValue<SteamLobbyVSP>(aSteamLobby).Search_Region;
            return val9;
        });

        SearchLobbyName = ValueOutput<string>("Search Lobby Name", (flow) =>
        {
            string val10 = flow.GetValue<SteamLobbyVSP>(aSteamLobby).Name;
            return val10;
        });

        SearchGameMode = ValueOutput<string>("Search Game Mode", (flow) =>
        {
            string val11 = flow.GetValue<SteamLobbyVSP>(aSteamLobby).Search_GameMode;
            return val11;
        });

        SearchExtraMode = ValueOutput<string>("Search Extra Mode", (flow) =>
        {
            string val12 = flow.GetValue<SteamLobbyVSP>(aSteamLobby).Search_ExtraMode;
            return val12;
        });
        SearchRankMin = ValueOutput<string>("Search Rank Min", (flow) =>
        {
            string val13 = flow.GetValue<SteamLobbyVSP>(aSteamLobby).Search_RankMin;
            return val13;
        });

        SearchRankMax = ValueOutput<string>("Search Rank Max", (flow) =>
        {
            string val14 = flow.GetValue<SteamLobbyVSP>(aSteamLobby).Search_RankMax;
            return val14;
        });

        SearchLevelMin = ValueOutput<string>("Search Level Min", (flow) =>
        {
            string val15 = flow.GetValue<SteamLobbyVSP>(aSteamLobby).Search_LevelMin;
            return val15;
        });

        SearchLevelMax = ValueOutput<string>("Search Level Max", (flow) =>
        {
            string val16 = flow.GetValue<SteamLobbyVSP>(aSteamLobby).Search_LevelMax;
            return val16;
        });

        SearchExtraNumber = ValueOutput<string>("Search Extra Number", (flow) =>
        {
            string val17 = flow.GetValue<SteamLobbyVSP>(aSteamLobby).Search_ExtraNumber;
            return val17;
        });
    }
}
