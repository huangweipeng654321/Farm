public struct SteamUserVSP
{
    public string Steam_Id;
    public string Steam_Name;
    public int Steam_Level;

    public bool Steam_IsMe;
    public bool Steam_IsOnline;
    public bool Steam_IsFriend;
}
