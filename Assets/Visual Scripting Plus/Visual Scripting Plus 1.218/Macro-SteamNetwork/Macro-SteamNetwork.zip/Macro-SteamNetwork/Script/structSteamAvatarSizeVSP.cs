public enum SteamAvatarSizeVSP
{
    Small,
    Medium,
    Large,
}