using UnityEngine;

public struct SteamUserPlusVSP
{
    public string Steam_Id;
    public string Steam_Name;
    public bool Steam_IsOnline;
    public int Steam_Level;
    public Texture2D Steam_Avatar;
}
