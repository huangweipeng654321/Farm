using Unity.Services.Vivox;
using Unity.VisualScripting;
using UnityEngine;

public class RosterItemVPS
{
    
    public VivoxParticipant Participant;
    public string DisplayName = "Unknown Name";
    public string UserID = "-1";
    public bool isMuted = false;
    public bool isSpeaking = false;
    public GameObject MacroUnityVivox;
    public void SetupRosterItem(VivoxParticipant participant,GameObject MacroUnityVivox_)
    {
        if (participant != null)
        {
            MacroUnityVivox = MacroUnityVivox_;
            Participant = participant;
            DisplayName = participant.DisplayName;
            UserID = participant.PlayerId;

            UpdateChatStateImage();
            Participant.ParticipantMuteStateChanged += onUpdateMicMuted;
            Participant.ParticipantSpeechDetected += onUpdateMicSpeaking;
        }
        else
        {
            Debug.Log("User unknown !");
        }
        
    }


    private void UpdateChatStateImage()
    {
        if (Participant.IsMuted)
        {
            isMuted = true;
            isSpeaking = false;
        }
        else
        {
            isMuted = false;
            if (Participant.SpeechDetected)
            {
                isSpeaking = true;
                
            }
            else
            {
                isSpeaking = false;
            }
        }
    }

    private void onUpdateMicSpeaking()
    {
        if (Participant.IsMuted)
        {
            isSpeaking = false;
        }
        else
        {
            if (Participant.SpeechDetected)
            {
                isSpeaking = true;
            }
            else
            {
                isSpeaking = false;
            }
        }
        CustomEvent.Trigger(MacroUnityVivox, "OnUpdateMicSpeaking", UserID, DisplayName, isSpeaking);
    }

    private void onUpdateMicMuted()
    {
        if (Participant.IsMuted)
        {
            isMuted = true;
        }
        else
        {
            isMuted = false;
        }
        CustomEvent.Trigger(MacroUnityVivox, "OnUpdateMicMuted", UserID, DisplayName, isMuted);
    }

    public int GetUserMicVolume()
    {
        if (!Participant.IsSelf)
        {
            return Participant.LocalVolume;
        }
        else
        {
            return 0;
        }
    }

    public void SetUserMicVolume(float number_)
    {
        if (!Participant.IsSelf)
        {
            if (number_ <= -50)
            {
                number_ = -50;
            }

            if (number_ > 50)
            {
                number_ = 50;
            }

            Participant.SetLocalVolume((int)number_);
        }
    }

    public double GetAudioEnergy()
    {
        if (Participant.IsSelf == true)
        {
            return Participant.AudioEnergy;
        }
        return 0;
    }
    private void OnDestroy()
    {
        Participant.ParticipantMuteStateChanged -= onUpdateMicMuted;
        Participant.ParticipantSpeechDetected -= onUpdateMicSpeaking;
    }
}
