﻿using UnityEngine;
using Unity.Services.Vivox;
using Unity.VisualScripting;
using System.Collections.Generic;
using Unity.Services.Authentication;
using Unity.Services.Core;
using System;
using UnityEngine.Android;
using System.Collections.ObjectModel;
using System.Collections;
public class UnityVivoxVPS : MonoBehaviour
{

    #region Initial
    public static UnityVivoxVPS Instance { get; private set; } = null;

    private float minVolume = -50; 
    private float defaultVolume = 0;
    private bool isInitialized = false;
    private bool isLoggedIn = false;
    private bool enableTTS = false;
    private bool autoAskPermission = false;
    private List<RosterItemVPS> rosterList = new List<RosterItemVPS>();
    private List<VivoxUserVPS> ListUserInfo = new List<VivoxUserVPS>();
    private string UserDisplayName = "Unknown Name";
    private RosterItemVPS MyParticipant = null;
    private string UserID = "null";
    private GameObject MacroUnityVivox;
    private string currentChannelName = "null"; 
    private bool isJoiningTextChannel = false;
    private List<string> ListTextChannel = new List<string>();
    private string FormatNewStringReplaceVSP(string Original_)
    {
        string newString_ = "";
        string FormatChars = "qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM0123456789_@= ăâôơưáàạảãắằặẳẵấầậẩẫốồộổỗớờợởỡứừựửữíìịỉĩđĐĂÂÔƠƯÁÀẠẢÃẮẰẶẲẴẤẦẬẨẪỐỒỘỔỖỚỜỢỞỠỨỪỰỬỮÍÌỊỈĨéèẻẽẹếềểễệêáàảãạÁÀẢÃẠóòỏõọÓÒỎÕỌÉÈẺẼẸẾỀỂỄỆÊúùủũụÚÙỦŨỤ";
        for (int i = 0; i < Original_.Length; i++)
        {
            string listChar_each = Original_[i].ToString();
            if (FormatChars.IndexOf(listChar_each) >= 0)
            {
                newString_ = newString_ + listChar_each;
            }

        }
        return newString_;
    }

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
        }
        else
        {
            Destroy(gameObject);
            return;
        }

        DontDestroyOnLoad(gameObject);

        MacroUnityVivox = FindObjectOfType<UnityVivoxVPS>().gameObject;
    }

    public bool AlreadyLoggedIn()
    {
        if (isInitialized == false)
        {
            return false;
        }
        else
        {
            return isLoggedIn;
        }
        
    }

    public void SetEnableTTS(bool Bool_)
    {
        enableTTS = Bool_;
    }

    public void setAutoAskPermission(bool Bool_value)
    {
        autoAskPermission = Bool_value;
    }

    public bool isInitial()
    {
        return isInitialized;
    }

    public bool AlreadyJoinedChannel()
    {
        if (currentChannelName == "null")
        {
            return false;
        }
        return true;
    }

    private void AddNewTextChannelToList(string name)
    {
        if (ListTextChannel.Contains(name) == false)
        {
            ListTextChannel.Add(name);
        }
    }
    private void RemoveTextChannelFromList(string name)
    {
        if (ListTextChannel.Contains(name) == true)
        {
            ListTextChannel.Remove(name);
        }
    }

    public bool AlreadyJoinedTextChannel()
    {
        if (ListTextChannel.Count <= 0)
        {
            return false;
        }
        return true;
    }

    public List<string> GetAllTextChannel()
    {
        return ListTextChannel;
    }
    private bool isChannelInTextChannelList(string name)
    {
        if (ListTextChannel.Contains(name) == true)
        {
            return true;
        }
        return false;
    }

    public string GetCurrentChannelName()
    {
        return currentChannelName;
    }

    public string GetYourUserID()
    {
        return UserID;
    }


    public async void InitializeAsync()
    {
        try
        {
            
            if (UnityServices.State != ServicesInitializationState.Initialized)
            {
                await UnityServices.InitializeAsync();
                if (AuthenticationService.Instance.IsAuthorized == false)
                {
                    await AuthenticationService.Instance.SignInAnonymouslyAsync();
                    await VivoxService.Instance.InitializeAsync();
                    

                    isInitialized = true;
                }
                else
                {
                    await VivoxService.Instance.InitializeAsync();
                    

                    isInitialized = true;
                }

                AddVivoxListener();
                CustomEvent.Trigger(MacroUnityVivox, "onInitialized");
                
            }
            else
            {
                Debug.Log("Vivox already initialized !");
                isInitialized = true;
                CustomEvent.Trigger(MacroUnityVivox, "onInitialized");
            }
            
        }
        catch(Exception ex)
        {
            Debug.Log("Initialize error : " + ex.ToString());
            CustomEvent.Trigger(MacroUnityVivox, "onInitialized_Error");
        }
        
    }

    public async void PreLogginVivox(string name)
    {
        try
        {
            
            if (isInitialized == false)
            {
                Debug.Log("Vivox is not initialized yet !");
                return;
            }

            if (isLoggedIn == true)
            {
                Debug.Log("Already signed in !");
                return;
            }

            if (name == null)
            {
                UserDisplayName = "Unknown Name";
            }
            else
            {
                if (name.Length >= 4)
                {
                    UserDisplayName = FormatNewStringReplaceVSP(name);
                    if (UserDisplayName.Length < 4)
                    {
                        Debug.Log("Display name can not use special chars. Using Default name");
                        UserDisplayName = "Unknown Name";
                    }
                }
                else
                {
                    Debug.Log("Display name length must be at least 4. Using Default name");
                    UserDisplayName = "Unknown Name";
                }
            }

            if (isLoggedIn == false)
            {
                if (autoAskPermission == true) 
                {
                    if (IsMicPermissionGranted())
                    {
                        await VivoxService.Instance.LogoutAsync();
                        LoginToVivoxAsync();
                    }
                    else
                    {
                        if (IsPermissionsDenied())
                        {
                            m_PermissionAskedCount = 0;

                            await VivoxService.Instance.LogoutAsync();
                            LoginToVivoxAsync();
                        }
                        else
                        {
                            AskForPermissions();
                        }
                    }
                }
                else
                {
                    await VivoxService.Instance.LogoutAsync();
                    LoginToVivoxAsync();

                } 

                
            }
        }
        catch (Exception ex)
        {
            Debug.Log("Log in error : " + ex.ToString());
            CustomEvent.Trigger(MacroUnityVivox, "onLoggedIn_Error");
        }

    }

    private void AddVivoxListener()
    {
        if (isInitialized == true)
        {
            VivoxService.Instance.LoggedIn += onLoggedIn;
            VivoxService.Instance.LoggedOut += onLoggedOut;
            VivoxService.Instance.ParticipantAddedToChannel += onParticipantAddedToChannel;
            VivoxService.Instance.ParticipantRemovedFromChannel += onParticipantRemovedFromChannel;
            VivoxService.Instance.ChannelJoined += onChannelJoined;
            VivoxService.Instance.ChannelLeft += onChannelLeft;
            VivoxService.Instance.ChannelMessageReceived += onChannelMessageReceived;
            VivoxService.Instance.DirectedMessageReceived += onDirectedMessageReceived;
            VivoxService.Instance.ChannelMessageDeleted += onChannelMessageDeleted;
            VivoxService.Instance.ChannelMessageEdited += onChannelMessageEdited;
            VivoxService.Instance.DirectedMessageDeleted += onDirectedMessageDeleted;
            VivoxService.Instance.DirectedMessageEdited += onDirectedMessageEdited;
            VivoxService.Instance.ConnectionFailedToRecover += onConnectionFailedToRecover;
            VivoxService.Instance.ConnectionRecovering += onConnectionRecovering;
            VivoxService.Instance.ConnectionRecovered += onConnectionRecovered;

            VivoxService.Instance.AvailableInputDevicesChanged += onAvailableInputDevicesChanged;
            VivoxService.Instance.AvailableOutputDevicesChanged += onAvailableOutputDevicesChanged;
        }
        
    }

    private void RemoveAllListener()
    {
        VivoxService.Instance.LoggedIn -= onLoggedIn;
        VivoxService.Instance.LoggedOut -= onLoggedOut;
        VivoxService.Instance.ParticipantAddedToChannel -= onParticipantAddedToChannel;
        VivoxService.Instance.ParticipantRemovedFromChannel -= onParticipantRemovedFromChannel;
        VivoxService.Instance.ChannelJoined -= onChannelJoined;
        VivoxService.Instance.ChannelLeft -= onChannelLeft;
        VivoxService.Instance.ChannelMessageReceived -= onChannelMessageReceived;
        VivoxService.Instance.DirectedMessageReceived -= onDirectedMessageReceived;
        VivoxService.Instance.ChannelMessageDeleted -= onChannelMessageDeleted;
        VivoxService.Instance.ChannelMessageEdited -= onChannelMessageEdited;
        VivoxService.Instance.DirectedMessageDeleted -= onDirectedMessageDeleted;
        VivoxService.Instance.DirectedMessageEdited -= onDirectedMessageEdited;
        VivoxService.Instance.ConnectionFailedToRecover -= onConnectionFailedToRecover;
        VivoxService.Instance.ConnectionRecovering -= onConnectionRecovering;
        VivoxService.Instance.ConnectionRecovered -= onConnectionRecovered;

        VivoxService.Instance.AvailableInputDevicesChanged -= onAvailableInputDevicesChanged;
        VivoxService.Instance.AvailableOutputDevicesChanged -= onAvailableOutputDevicesChanged;
    }

    private void OnDestroy()
    {
        if (isInitialized == true) 
        {
            RemoveAllListener();
        }
    }

    public async void LoginToVivoxAsync()
    {
        try
        {

            if (AlreadyLoggedIn() == false)
            {
                LoginOptions options = new LoginOptions();
                options.DisplayName = UserDisplayName;
                options.ParticipantUpdateFrequency = ParticipantPropertyUpdateFrequency.FivePerSecond;
                
                if (enableTTS == true)
                {
                    options.EnableTTS = true;
                }

                if (isInitialized == true && isLoggedIn == false)
                {
                    //Debug.Log("Sign in ... progressing");
                    await VivoxService.Instance.LoginAsync(options);
                    UserID = VivoxService.Instance.SignedInPlayerId.ToString();
                }
                
            }
            else
            {
                Debug.Log("Vivox already Logged in!");
            }
        }
        catch (Exception ex)
        {
            Debug.Log("Log in error : " + ex.ToString());
            CustomEvent.Trigger(MacroUnityVivox, "onLoggedIn_Error");
        }
    }

    private void onLoggedIn()
    {
        currentChannelName = "null";
        isLoggedIn = true;
        CustomEvent.Trigger(MacroUnityVivox, "onLoggedIn", VivoxService.Instance.SignedInPlayerId.ToString());
    }
    

    public async void LogoutOfVivoxAsync()
    {
        try
        {
            if (AlreadyJoinedChannel() == true)
            {
                Debug.Log("Still in channel. Need to Leave channel first ! ");
                CustomEvent.Trigger(MacroUnityVivox, "onLoggedOut_Error");
                return;
            }

            if (AlreadyLoggedIn() == true)
            {
                await VivoxService.Instance.LogoutAsync();
                
            }
            else
            {
                Debug.Log("Not signed in yet ! ");
                CustomEvent.Trigger(MacroUnityVivox, "onLoggedOut_Error");
            }
        }
        catch (Exception ex)
        {
            Debug.Log("Log out error : " + ex.ToString());
            CustomEvent.Trigger(MacroUnityVivox, "onLoggedOut_Error");
        }

    }
    private void onLoggedOut()
    {
        isLoggedIn = false;
        UserID = "null";
        CustomEvent.Trigger(MacroUnityVivox, "onLoggedOut");
    }

    public List<VivoxUserVPS> GetAllUsersInfo()
    {
        List<VivoxUserVPS> newListUser = new List<VivoxUserVPS>();
        VivoxUserVPS newUser = new VivoxUserVPS();
        for (int i = 0; i < rosterList.Count; i++)
        {
            newUser.DisplayName = rosterList[i].DisplayName;
            newUser.UserID = rosterList[i].UserID;
            newUser.isMuted = rosterList[i].isSpeaking;
            newUser.isSpeaking = rosterList[i].isMuted;
            newListUser.Add(newUser);
        }

        ListUserInfo = newListUser;
        return ListUserInfo;
    }

    #endregion

    #region MicPermission

    int m_PermissionAskedCount;

#if (UNITY_ANDROID && !UNITY_EDITOR) || __ANDROID__
    bool IsAndroid12AndUp()
    {
        // android12VersionCode is hardcoded because it might not be available in all versions of Android SDK
        const int android12VersionCode = 31;
        AndroidJavaClass buildVersionClass = new AndroidJavaClass("android.os.Build$VERSION");
        int buildSdkVersion = buildVersionClass.GetStatic<int>("SDK_INT");

        return buildSdkVersion >= android12VersionCode;
    }

    string GetBluetoothConnectPermissionCode()
    {
        if (IsAndroid12AndUp())
        {
            // UnityEngine.Android.Permission does not contain the BLUETOOTH_CONNECT permission, fetch it from Android
            AndroidJavaClass manifestPermissionClass = new AndroidJavaClass("android.Manifest$permission");
            string permissionCode = manifestPermissionClass.GetStatic<string>("BLUETOOTH_CONNECT");

            return permissionCode;
        }

        return "";
    }
#endif

    bool IsMicPermissionGranted()
    {
        bool isGranted = Permission.HasUserAuthorizedPermission(Permission.Microphone);
        
#if (UNITY_ANDROID && !UNITY_EDITOR) || __ANDROID__
                if (IsAndroid12AndUp())
                {
                    // On Android 12 and up, we also need to ask for the BLUETOOTH_CONNECT permission for all features to work
                    isGranted &= Permission.HasUserAuthorizedPermission(GetBluetoothConnectPermissionCode());
                }
#endif
        return isGranted;
    }

    void AskForPermissions()
    {
        string permissionCode = Permission.Microphone;

#if (UNITY_ANDROID && !UNITY_EDITOR) || __ANDROID__
        if (m_PermissionAskedCount == 1 && IsAndroid12AndUp())
        {
            permissionCode = GetBluetoothConnectPermissionCode();
        }
#endif
        m_PermissionAskedCount++;
        Permission.RequestUserPermission(permissionCode);
    }

    bool IsPermissionsDenied()
    {
#if (UNITY_ANDROID && !UNITY_EDITOR) || __ANDROID__
        // On Android 12 and up, we also need to ask for the BLUETOOTH_CONNECT permission
        if (IsAndroid12AndUp())
        {
            return m_PermissionAskedCount == 2;
        }
#endif
        return m_PermissionAskedCount == 1;
    }


    #endregion

    #region Join Leave Channel

    public async void JoinEchoChannelAsync()
    {
        try
        {
            if (VivoxService.Instance.IsLoggedIn == true)
            {
                if (AlreadyJoinedChannel() == true)
                {
                    Debug.Log("Already in channel ! You need to leave channel before joining in another.");
                    CustomEvent.Trigger(MacroUnityVivox, "onChannelJoined_Error");
                    return;
                }

                isJoiningTextChannel = false;
                isWaitingAction = true;
                await VivoxService.Instance.JoinEchoChannelAsync("Mic", ChatCapability.AudioOnly);
                isWaitingAction = false;
            }
            else
            {
                Debug.Log("Need to Sign in first !");
            }
        }
        catch (Exception ex)
        {
            Debug.Log("Join channel error : " + ex.ToString());
            CustomEvent.Trigger(MacroUnityVivox, "onChannelJoined_Error");
        }

    }

    public async void JoinGroupChannelAsync(string ChannelName, VivoxRoomVoiceVPS type_)
    {
        try
        {
            if (VivoxService.Instance.IsLoggedIn == true)
            {
                
                if (AlreadyJoinedChannel() == true)
                {
                    Debug.Log("Already in channel ! You need to leave channel before joining in another.");
                    CustomEvent.Trigger(MacroUnityVivox, "onChannelJoined_Error");
                    return;
                }

                if (ChannelName.Length >= 4)
                {
                    var newName = FormatNewStringReplaceVSP(ChannelName);
                    ChannelName = newName;
                    if (ChannelName.Length < 4)
                    {
                        Debug.Log("Channel name length must be at least 4!");
                        return;
                    }
                }
                else
                {
                    Debug.Log("Channel name length must be at least 4!");
                    return;
                }

                var ChatCapability_ = ChatCapability.TextAndAudio;

                if (type_ == VivoxRoomVoiceVPS.AudioOnly)
                {
                    ChatCapability_ = ChatCapability.AudioOnly;
                }
                else
                {
                    ChatCapability_ = ChatCapability.TextAndAudio;
                }

                var channelName_ = FormatNewStringReplaceVSP(ChannelName);
                if (channelName_.Length > 0)
                {
                    if (ListTextChannel.Contains(channelName_) == true)
                    {
                        Debug.Log("Channel name is invalid. Not same name as any Text Channels !");
                        CustomEvent.Trigger(MacroUnityVivox, "onChannelJoined_Error");
                    }
                    else
                    {
                        isJoiningTextChannel = false;
                        isWaitingAction = true;
                        await VivoxService.Instance.JoinGroupChannelAsync(ChannelName, ChatCapability_);
                        isWaitingAction = false;
                    }
                    
                }
                else
                {
                    Debug.Log("Channel name is invalid !");
                    CustomEvent.Trigger(MacroUnityVivox, "onChannelJoined_Error");
                }
            }
            else
            {
                Debug.Log("Need to Sign in first !");
            }
        }
        catch (Exception ex)
        {
            Debug.Log("Join channel error : " + ex.ToString());
            CustomEvent.Trigger(MacroUnityVivox, "onChannelJoined_Error");
        }

    }

    public async void JoinMultiTextChannelAsync(string ChannelName)
    {
        try
        {
            if (VivoxService.Instance.IsLoggedIn == true)
            {
                var channelName_ = FormatNewStringReplaceVSP(ChannelName);

                if (ListTextChannel.Contains(channelName_) == true)
                {
                    Debug.Log("Already joined in this text channel !");
                    return;
                }

                if (channelName_.Length >= 4)
                {
                    var newName = FormatNewStringReplaceVSP(ChannelName);
                    ChannelName = newName;
                    if (ChannelName.Length < 4)
                    {
                        Debug.Log("Channel name length must be at least 4!");
                        return;
                    }
                }
                else
                {
                    Debug.Log("Channel name length must be at least 4!");
                    return;
                }

                var ChatCapability_ = ChatCapability.TextOnly;

                
                if (channelName_.Length > 0 && channelName_ != currentChannelName)
                {
                    isJoiningTextChannel = true;
                    isWaitingAction = true;
                    await VivoxService.Instance.JoinGroupChannelAsync(ChannelName, ChatCapability_);
                    isWaitingAction = false;
                }
                else
                {
                    Debug.Log("Channel name is invalid !");
                    CustomEvent.Trigger(MacroUnityVivox, "onChannelMultiJoined_Error");
                }
            }
            else
            {
                Debug.Log("Need to Sign in first !");
            }
        }
        catch (Exception ex)
        {
            Debug.Log("Join multi text channel error : " + ex.ToString());
            CustomEvent.Trigger(MacroUnityVivox, "onChannelMultiJoined_Error");
        }

    }

    
    private void onChannelJoined(string name)
    {
        if (isJoiningTextChannel == true)
        {
            AddNewTextChannelToList(name);
        }
        else
        {
            currentChannelName = name;
        }
        
        CustomEvent.Trigger(MacroUnityVivox, "onChannelJoined");
    }

    public async void LeaveEchoChannelAsync()
    {
        try
        {
            if (VivoxService.Instance.IsLoggedIn == true && currentChannelName != "null")
            {
                isWaitingAction = true;
                await VivoxService.Instance.LeaveChannelAsync(currentChannelName);
                isWaitingAction = false;
            }
            else
            {
                CustomEvent.Trigger(MacroUnityVivox, "onChannelLeft_Error");
            }
        }
        catch (Exception ex)
        {
            Debug.Log("Leave channel error : " + ex.ToString());
            CustomEvent.Trigger(MacroUnityVivox, "onChannelLeft_Error");
        }

    }
    private void onChannelLeft(string ChannelName)
    {
        if (currentChannelName == ChannelName)
        {
            currentChannelName = "null";
        }
        RemoveTextChannelFromList(ChannelName);

        for (int i = rosterList.Count - 1; i >= 0; i--)
        {
            rosterList.RemoveAt(i);
        }
        rosterList = new List<RosterItemVPS>();
        ListUserInfo = new List<VivoxUserVPS>();

        CustomEvent.Trigger(MacroUnityVivox, "onChannelLeft", ChannelName);
    }

    IEnumerator WaitToLeaveAllChannelAgain()
    {
        yield return new WaitForSeconds(0.5f);
        //Debug.Log("After wait 1 sec!");
        LeaveAllChannelAsync();
    }

    private bool isWaitingAction = false; 
    public async void LeaveAllChannelAsync()
    {
        try
        {
            if (VivoxService.Instance.IsLoggedIn == true)
            {
                if (isWaitingAction == true)
                {
                    StartCoroutine(WaitToLeaveAllChannelAgain());
                    return;
                }

                isWaitingAction = true;
                await VivoxService.Instance.LeaveAllChannelsAsync();
                isWaitingAction = false;

                ListTextChannel = new List<string>();
                currentChannelName = "null";
                CustomEvent.Trigger(MacroUnityVivox, "onChannelLeftAll_Done");
                
            }
            else
            {
                Debug.Log("Not sign in yet : ");
                CustomEvent.Trigger(MacroUnityVivox, "onChannelLeftAll_Error");
            }
        }
        catch (Exception ex)
        {
            Debug.Log("Leave all channel error : " + ex.ToString());
            CustomEvent.Trigger(MacroUnityVivox, "onChannelLeftAll_Error");
        }

    }

    IEnumerator WaitToLeaveAChannelAgain(string ChannelName)
    {
        yield return new WaitForSeconds(0.5f);
        //Debug.Log("After wait 1 sec!");
        LeaveAChannel(ChannelName);
    }
    public async void LeaveAChannel(string ChannelName)
    {
        try
        {
            if (VivoxService.Instance.IsLoggedIn == true)
            {
                if (isWaitingAction == true)
                {
                    //Debug.Log("You are waiting some async to Leave a channel... ");
                    StartCoroutine(WaitToLeaveAChannelAgain(ChannelName));
                    //CustomEvent.Trigger(MacroUnityVivox, "onChannelLeftOne_Error");
                    return;
                }

                isWaitingAction = true;
                await VivoxService.Instance.LeaveChannelAsync(ChannelName);
                isWaitingAction = false;

                CustomEvent.Trigger(MacroUnityVivox, "onChannelLeftOne_Done");
            }
            else
            {
                Debug.Log("Not sign in yet : ");
                CustomEvent.Trigger(MacroUnityVivox, "onChannelLeftOne_Error");
            }
        }
        catch (Exception ex)
        {
            Debug.Log("Leave a channel error : " + ex.ToString());
            CustomEvent.Trigger(MacroUnityVivox, "onChannelLeftOne_Error");
        }

    }

    #endregion

    #region On Join in out channel
    private void onParticipantAddedToChannel(VivoxParticipant participant)
    {
        if (isChannelInTextChannelList(participant.ChannelName) == false)
        {
            RosterItemVPS newRosterItem = new RosterItemVPS();
            newRosterItem.SetupRosterItem(participant, MacroUnityVivox);
            rosterList.Add(newRosterItem);
            
            if (participant.PlayerId == UserID)
            {
                MyParticipant = newRosterItem;
            }
        }

        Debug.Log(participant.DisplayName + " joined in channel :" + participant.ChannelName);
        CustomEvent.Trigger(MacroUnityVivox, "OnUserAddedToChannel", participant.PlayerId, participant.DisplayName, participant.IsMuted, participant.ChannelName);
    }


    private void onParticipantRemovedFromChannel(VivoxParticipant participant)
    {
        Debug.Log(participant.DisplayName + " : is left channel " + participant.ChannelName + " !");
        if (isChannelInTextChannelList(participant.ChannelName) == false)
        {
            RemoveUserFromListRoster(participant.PlayerId);
        }
            

        if (participant.PlayerId == UserID)
        {
            MyParticipant = null;
        }

        CustomEvent.Trigger(MacroUnityVivox, "OnUserLeftChannel", participant.PlayerId, participant.DisplayName, participant.ChannelName);
    }

    private void RemoveUserFromListRoster(string userID)
    {
        try
        {
            int found = -1;
            for (int i = 0; i < rosterList.Count; i++)
            {
                if (rosterList[i].Participant.PlayerId == userID)
                {
                    found = i;
                    break;
                }

            }

            if (found >= 0)
            {
                rosterList.RemoveAt(found);
            }
        }
        catch (Exception ex)
        {
            Debug.Log("Remove user from list users error :" + ex.ToString());
        }
    }

    #endregion

    #region Send Message

    IEnumerator WaitToSendMessageAgain(string channelName, string message)
    {
        yield return new WaitForSeconds(0.5f);
        //Debug.Log("After wait 1 sec!");
        SendMessageAsync(channelName, message);
    }
    public async void SendMessageAsync(string channelName, string message)
    {
        
        try
        {
            if (isLoggedIn == true)
            {
                if (currentChannelName == channelName || ListTextChannel.Contains(channelName) == true)
                {
                    if (isWaitingAction == true) 
                    {
                        //Debug.Log("You are waiting for some async message !");
                        StartCoroutine(WaitToSendMessageAgain(channelName, message));
                        return;
                    }

                    isWaitingAction = true;
                    await VivoxService.Instance.SendChannelTextMessageAsync(channelName, message);
                    isWaitingAction = false;
                    CustomEvent.Trigger(MacroUnityVivox, "onSendMessageChannel_Success");
                }
                else
                {
                    Debug.Log("You are not a member in this channel !");
                }
                
            }
            else
            {
                Debug.Log("Need to sign in first !");
            }
            
            /* old
            if (AlreadyJoinedChannel() == true)
            {
                await VivoxService.Instance.SendChannelTextMessageAsync(channelName, message);
                CustomEvent.Trigger(MacroUnityVivox, "onSendMessageChannel_Success");
            }
            else
            {
                Debug.Log("Need to join in Channel first !");
                CustomEvent.Trigger(MacroUnityVivox, "onSendMessageChannel_Error");
            }
            */
        }
        catch (Exception ex)
        {
            Debug.Log("Send Message channel error : " + ex.ToString());
            CustomEvent.Trigger(MacroUnityVivox, "onSendMessageChannel_Error");
        }
    }
    
    private void onChannelMessageReceived(VivoxMessage message)
    {
        var msg = ConvertToMessageVPS(message);

        CustomEvent.Trigger(MacroUnityVivox, "onChannelMessageReceived", msg);
    }

    public async void SendDirectMessageAsync(string userID, string message)
    {
        try
        {
            if (isLoggedIn == true)
            {
                isWaitingAction = true;
                await VivoxService.Instance.SendDirectTextMessageAsync(userID, message);
                isWaitingAction = false;
                CustomEvent.Trigger(MacroUnityVivox, "onSendDM_Success");
            }
            else
            {
                Debug.Log("Need to sign in first !");
            }

        }
        catch (Exception ex)
        {
            Debug.Log("Direct message error :" + ex.ToString());
        }
    }
    private void onDirectedMessageReceived(VivoxMessage message)
    {
        var msg = ConvertToMessageVPS(message);

        CustomEvent.Trigger(MacroUnityVivox, "onDirectMessageReceived", msg);
    }

    public async void GetMessageHistoryChannel(string channelName, int totalSize)
    {
        try
        {
            if (isLoggedIn == false)
            {
                Debug.Log("Must sign in first!");
                return;
            }

            if (currentChannelName == channelName || ListTextChannel.Contains(channelName) == true)
            {
                List<VivoxMessageVPS> newMesgList = new List<VivoxMessageVPS>();

                isWaitingAction = true;
                var msgList = await VivoxService.Instance.GetChannelTextMessageHistoryAsync(channelName, totalSize);
                isWaitingAction = false;

                for (int i = 0; i < msgList.Count; i++)
                {
                    var msg = ConvertToMessageVPS(msgList[i]);
                    newMesgList.Add(msg);
                }

                CustomEvent.Trigger(MacroUnityVivox, "onMsgHistory_Success", newMesgList);
            }
            else
            {
                Debug.Log("Must join in channel first!");
                CustomEvent.Trigger(MacroUnityVivox, "onMsgHistory_Fail");
                return;
            }


            
        }
        catch (Exception ex)
        {
            Debug.Log("Get history messages of channel error :" + ex.ToString());
            CustomEvent.Trigger(MacroUnityVivox, "onMsgHistory_Fail");
        }

    }

    public async void DeleteAMessage(string channelName, string messageID)
    {
        try
        {
            if (isLoggedIn == false)
            {
                Debug.Log("Must sign in first!");
                return;
            }
            
            if (currentChannelName == channelName || ListTextChannel.Contains(channelName) == true)
            {
                isWaitingAction = true;
                await VivoxService.Instance.DeleteChannelTextMessageAsync(channelName, messageID);
                isWaitingAction = false;
                CustomEvent.Trigger(MacroUnityVivox, "onDeleteMessage_Success", messageID);
            }
            else
            {
                Debug.Log("Must join in channel first!");
                CustomEvent.Trigger(MacroUnityVivox, "onDeleteMessage_Fail");
                return;
            }


        }
        catch (Exception ex)
        {
            Debug.Log("Delete a message error :" + ex.ToString());
            CustomEvent.Trigger(MacroUnityVivox, "onDeleteMessage_Fail");
        }

    }

    public async void ReadAMessage(string channelName, string messageID)
    {
        try
        {
            if (isLoggedIn == false)
            {
                Debug.Log("Must sign in first!");
                return;
            }

            if (currentChannelName == channelName || ListTextChannel.Contains(channelName) == true)
            {
                isWaitingAction = true;
                await VivoxService.Instance.DeleteChannelTextMessageAsync(channelName, messageID);
                isWaitingAction = false;
                CustomEvent.Trigger(MacroUnityVivox, "onReadMessage_Success", messageID);
            }


        }
        catch (Exception ex)
        {
            Debug.Log("Read a message error :" + ex.ToString());
            CustomEvent.Trigger(MacroUnityVivox, "onReadMessage_Fail");
        }

    }


    private VivoxMessageVPS ConvertToMessageVPS(VivoxMessage message_)
    {
        VivoxMessageVPS newMsg = new VivoxMessageVPS();
        newMsg.ChannelName = message_.ChannelName;
        newMsg.SenderID = message_.SenderPlayerId;
        newMsg.SenderName = message_.SenderDisplayName;
        newMsg.MessageID = message_.MessageId;
        newMsg.MessageText = message_.MessageText;
        newMsg.ReceivedTime = message_.ReceivedTime;

        return newMsg;
    }

    public async void GetMessageHistoryDM(string userID, int totalSize)
    {
        try
        {
            if (isLoggedIn == false)
            {
                Debug.Log("Must sign in first!");
                return;
            }


            List<VivoxMessageVPS> newMesgList = new List<VivoxMessageVPS>();

            isWaitingAction = true;
            var msgList = await VivoxService.Instance.GetDirectTextMessageHistoryAsync(userID, totalSize);
            isWaitingAction = false;
            for (int i = 0; i < msgList.Count; i++)
            {
                var msg = ConvertToMessageVPS(msgList[i]);
                newMesgList.Add(msg);
            }

            CustomEvent.Trigger(MacroUnityVivox, "onMsgHistoryDM_Success", newMesgList);
        }
        catch (Exception ex)
        {
            Debug.Log("Get history direct messages error :" + ex.ToString());
            CustomEvent.Trigger(MacroUnityVivox, "onMsgHistoryDM_Fail");
        }

    }

    public async void DeleteADirectMessage(string messageID)
    {
        try
        {
            if (isLoggedIn == false)
            {
                Debug.Log("Must sign in first!");
                return;
            }
            isWaitingAction = true;
            await VivoxService.Instance.DeleteDirectTextMessageAsync(messageID);
            isWaitingAction = false;
            CustomEvent.Trigger(MacroUnityVivox, "onDeleteDM_Success", messageID);
        }
        catch (Exception ex)
        {
            Debug.Log("Delete a message error :" + ex.ToString());
            CustomEvent.Trigger(MacroUnityVivox, "onDeleteDM_Fail");
        }

    }


    public async void BlockUserAsync(string userID)
    {

        try
        {
            if (isLoggedIn == false)
            {
                Debug.Log("Must sign in first!");
                return;
            }

            isWaitingAction = true;
            await VivoxService.Instance.BlockPlayerAsync(userID);
            isWaitingAction = false;
            CustomEvent.Trigger(MacroUnityVivox, "onBlockUser_Success");
        }
        catch (Exception ex)
        {
            Debug.Log("Block user error : " + ex.ToString());
            CustomEvent.Trigger(MacroUnityVivox, "onBlockUser_Error");
        }
    }

    public async void UnBlockUserAsync(string userID)
    {

        try
        {
            if (isLoggedIn == false)
            {
                Debug.Log("Must sign in first!");
                return;
            }

            isWaitingAction = true;
            await VivoxService.Instance.UnblockPlayerAsync(userID);
            isWaitingAction = false;
            CustomEvent.Trigger(MacroUnityVivox, "onUnBlockUser_Success");
            
        }
        catch (Exception ex)
        {
            Debug.Log("Unblock user error : " + ex.ToString());
            CustomEvent.Trigger(MacroUnityVivox, "onUnBlockUser_Error");
        }
    }

    #endregion

    #region MuteAndSpeakerOnOff
    public void SetSpeakerOnOff(string userID, bool Bool_)
    {
        try
        {
            if (userID == UserID) //isMe
            {
                Debug.Log("Can not do it on your own User !");
                return;
            }

            int found = -1;
            for (int i = 0; i < rosterList.Count; i++)
            {
                if (rosterList[i].Participant.PlayerId == userID)
                {
                    found = i;
                    break;
                }

            }

            if (found >= 0)
            {
                if (Bool_ == true)
                {
                    rosterList[found].SetUserMicVolume(minVolume);
                }
                else
                {
                    rosterList[found].SetUserMicVolume(defaultVolume);
                }
            }
        }
        catch (Exception ex)
        {
            Debug.Log("Speaker on off error :" + ex.ToString());
        }

        
        
    }

    public void AdjustUserVolume(string userID, float number)
    {
        try
        {
            if (userID == UserID) //isMe
            {
                Debug.Log("Can not do it on your own User !");
                return;
            }

            int found = -1;
            for (int i = 0; i < rosterList.Count; i++)
            {
                if (rosterList[i].Participant.PlayerId == userID)
                {
                    found = i;
                    break;
                }

            }

            if (found >= 0)
            {
                rosterList[found].SetUserMicVolume(number);
            }
        }
        catch (Exception ex)
        {
            Debug.Log("Adjust User Volume error :" + ex.ToString());
        }



    }

    public void MuteSelf(bool Bool_)
    {
        try
        {
            int found = -1;
            for (int i = 0; i < rosterList.Count; i++)
            {
                if (rosterList[i].Participant.PlayerId == UserID)
                {
                    found = i;
                    break;
                }

            }

            if (found >= 0)
            {
                if (Bool_ == true)
                {
                    rosterList[found].Participant.MutePlayerLocally();
                }
                else
                {
                    rosterList[found].Participant.UnmutePlayerLocally();
                }
            }

        }
        catch (Exception ex)
        {
            Debug.Log("Mute self error :" + ex.ToString());
        }
    }

    public int GetVolumeInputDevice()
    {
        int volume_ = -999;
        try
        {
            if (isInitialized == false)
            {
                Debug.Log("Vivox is not initialized yet !");
                return volume_;
            }

            volume_ = VivoxService.Instance.InputDeviceVolume;

            
            return volume_;
        }
        catch (Exception ex)
        {
            Debug.Log("Get volume input device error :" + ex.ToString());
            return volume_;
        }
    }

    public int GetVolumeOutputDevice()
    {
        int volume_ = -999;
        try
        {
            if (isInitialized == false)
            {
                Debug.Log("Vivox is not initialized yet !");
                return volume_;
            }

            volume_ = VivoxService.Instance.OutputDeviceVolume;

            return volume_;
        }
        catch (Exception ex)
        {
            Debug.Log("Get volume output device error :" + ex.ToString());
            return volume_;
        }
    }

    public void SetVolumeInputDevice(int number)
    {
        try
        {
            if (isInitialized == false)
            {
                Debug.Log("Vivox is not initialized yet !");
                return ;
            }

            VivoxService.Instance.SetInputDeviceVolume(number);

        }
        catch (Exception ex)
        {
            Debug.Log("Set volume input device error :" + ex.ToString());
        }
    }

    public void SetVolumeOutputDevice(int number)
    {
        try
        {
            if (isInitialized == false)
            {
                Debug.Log("Vivox is not initialized yet !");
                return;
            }

            VivoxService.Instance.SetOutputDeviceVolume(number);

        }
        catch (Exception ex)
        {
            Debug.Log("Set volume output device error :" + ex.ToString());
        }
    }

    public void GetSensivity(int number)
    {
        try
        {
            if (isInitialized == false)
            {
                Debug.Log("Vivox is not initialized yet !");
                return;
            }

            VivoxService.Instance.SetVoiceActivityDetectionPropertiesAsync(1, 1, 1);
            VivoxService.Instance.EnableAutoVoiceActivityDetectionAsync();
            
        }
        catch (Exception ex)
        {
            Debug.Log("Set volume output device error :" + ex.ToString());
        }
    }

    #endregion

    #region OnDeleteEditMessage

    public async void EditMessageAsync(string channelName, string message, string messageID)
    {
        try
        {
            if (currentChannelName == channelName || ListTextChannel.Contains(channelName) == true)
            {
                isWaitingAction = true;
                await VivoxService.Instance.EditChannelTextMessageAsync(channelName, messageID, message);
                isWaitingAction = false;
                CustomEvent.Trigger(MacroUnityVivox, "onEditMessage_Success");
            }
            else
            {
                Debug.Log("Must join in channel first!");
                CustomEvent.Trigger(MacroUnityVivox, "onEditMessage_Error");
                return;
            }

        }
        catch (Exception ex)
        {
            Debug.Log("Edit Message channel error : " + ex.ToString());
            CustomEvent.Trigger(MacroUnityVivox, "onEditMessage_Error");
        }
    }

    public async void EditDirectMessageAsync(string message, string messageID)
    {
        try
        {
            if (isLoggedIn == false)
            {
                Debug.Log("Need to sign in first !");
                return;
            }
            isWaitingAction = true;
            await VivoxService.Instance.EditDirectTextMessageAsync(messageID, message);
            isWaitingAction = false;
            CustomEvent.Trigger(MacroUnityVivox, "onEditDM_Success");
        }
        catch (Exception ex)
        {
            Debug.Log("Edit direct message error : " + ex.ToString());
            CustomEvent.Trigger(MacroUnityVivox, "onEditDM_Error");
        }
    }

    private void onChannelMessageDeleted(VivoxMessage message)
    {
        string msgID = message.MessageId;
        CustomEvent.Trigger(MacroUnityVivox, "onChannelMessageDeleted", msgID);
    }
    private void onDirectedMessageDeleted(VivoxMessage message)
    {
        string msgID = message.MessageId;
        CustomEvent.Trigger(MacroUnityVivox, "onDirectedMessageDeleted", msgID);
    }

    private void onChannelMessageEdited(VivoxMessage message)
    {
        var msg = ConvertToMessageVPS(message);
        CustomEvent.Trigger(MacroUnityVivox, "onChannelMessageEdited", msg);
    }
    
    private void onDirectedMessageEdited(VivoxMessage message)
    {
        var msg = ConvertToMessageVPS(message);
        CustomEvent.Trigger(MacroUnityVivox, "onDirectedMessageEdited", msg);
    }

    #endregion

    #region OnConnectRecover

    private void onConnectionFailedToRecover()
    {
        CustomEvent.Trigger(MacroUnityVivox, "onConnectionFailedToRecover");
    }
    private void onConnectionRecovering()
    {
        CustomEvent.Trigger(MacroUnityVivox, "onConnectionRecovering");
    }
    private void onConnectionRecovered()
    {
        CustomEvent.Trigger(MacroUnityVivox, "onConnectionRecovered");
    }

    #endregion

    #region InputMic

    private List<VivoxInputDeviceVPS> ConvertInputDevicesVPS(ReadOnlyCollection<VivoxInputDevice> list_)
    {
        List<VivoxInputDeviceVPS> newList = new List<VivoxInputDeviceVPS>();
        foreach (var item in list_)
        {
            VivoxInputDeviceVPS newItem = new VivoxInputDeviceVPS();
            newItem.Device = item;
            newItem.DeviceID = item.DeviceID;
            newItem.DeviceName = item.DeviceName;

            newList.Add(newItem);
        }
        return newList;
    }
    private List<VivoxOutputDeviceVPS> ConvertOutputDevicesVPS(ReadOnlyCollection<VivoxOutputDevice> list_)
    {
        List<VivoxOutputDeviceVPS> newList = new List<VivoxOutputDeviceVPS>();
        foreach (var item in list_)
        {
            VivoxOutputDeviceVPS newItem = new VivoxOutputDeviceVPS();
            newItem.Device = item;
            newItem.DeviceID = item.DeviceID;
            newItem.DeviceName = item.DeviceName;

            newList.Add(newItem);
        }
        return newList;
    }
    public List<VivoxInputDeviceVPS> GetAvailableInputDevices()
    {
        List<VivoxInputDeviceVPS> result = new List<VivoxInputDeviceVPS>();
        try
        {
            if (isInitialized == false)
            {
                Debug.Log("Vivox is not initialized yet !");
                return result;
            }

            result = ConvertInputDevicesVPS(VivoxService.Instance.AvailableInputDevices);
            
            return result;
        }
        catch (Exception ex)
        {
            Debug.Log("Get available input devices error :" + ex.ToString());
            return result;
        }

        
    }

    public List<VivoxOutputDeviceVPS> GetAvailableOutputDevices()
    {
        List<VivoxOutputDeviceVPS> result = new List<VivoxOutputDeviceVPS>();
        try
        {
            if (isInitialized == false)
            {
                Debug.Log("Vivox is not initialized yet !");
                return result;
            }

            result = ConvertOutputDevicesVPS(VivoxService.Instance.AvailableOutputDevices);
            return result;

        }
        catch (Exception ex)
        {
            Debug.Log("Get available output devices error :" + ex.ToString());
            return result;
        }


    }

    private void onAvailableInputDevicesChanged()
    {
        CustomEvent.Trigger(MacroUnityVivox, "onAvailableInputDevicesChanged");
    }
    private void onAvailableOutputDevicesChanged()
    {
        CustomEvent.Trigger(MacroUnityVivox, "onAvailableOutputDevicesChanged");
    }

    private VivoxInputDevice GetInputDeviceFromID(string InputDeviceID_) 
    {
        var devices = GetAvailableInputDevices();

        foreach (var device in devices)
        {
            if (device.DeviceID == InputDeviceID_)
            {
                return device.Device;
            }
        }
        return null;
    }
    private VivoxOutputDevice GetOutputDeviceFromID(string outputDeviceID_)
    {
        var devices = GetAvailableOutputDevices();

        foreach (var device in devices)
        {
            if (device.DeviceID == outputDeviceID_)
            {
                return device.Device;
            }
        }
        return null;
    }
    public async void SetInputDevice(string InputDeviceID_) 
    {
        try
        {
            if (isInitialized == false)
            {
                Debug.Log("Vivox is not initialized yet !");
                return;
            }

            var newDevice = GetInputDeviceFromID(InputDeviceID_);
            isWaitingAction = true;
            await VivoxService.Instance.SetActiveInputDeviceAsync(newDevice);
            isWaitingAction = false;
            CustomEvent.Trigger(MacroUnityVivox, "onSetInputDevice");
        }
        catch (Exception ex)
        {
            Debug.Log("Set input device error :" + ex.ToString());
            CustomEvent.Trigger(MacroUnityVivox, "onSetInputDevice_Error");
        }
    }

    public void SetOutputDevice(string outputDeviceID_)
    {
        try
        {
            if (isInitialized == false)
            {
                Debug.Log("Vivox is not initialized yet !");
                return;
            }

            var newDevice = GetOutputDeviceFromID(outputDeviceID_);
            VivoxService.Instance.SetActiveOutputDeviceAsync(newDevice);
            CustomEvent.Trigger(MacroUnityVivox, "onSetOutputDevice");

        }
        catch (Exception ex)
        {
            Debug.Log("Set output device error :" + ex.ToString());
            CustomEvent.Trigger(MacroUnityVivox, "onSetOutputDevice_Error");
        }
    }

    public VivoxInputDeviceVPS GetActiveInputDevice()
    {
        VivoxInputDeviceVPS result = new VivoxInputDeviceVPS();
        try
        {
            if (isInitialized == false)
            {
                Debug.Log("Vivox is not initialized yet !");
                return result;
            }

            var device_ = VivoxService.Instance.ActiveInputDevice;

            result.Device = device_;
            result.DeviceID = device_.DeviceID;
            result.DeviceName = device_.DeviceName;

            return result;
        }
        catch (Exception ex)
        {
            Debug.Log("Get active input device error :" + ex.ToString());
            return result;
        }


    }

    public VivoxOutputDeviceVPS GetActiveOutputDevice()
    {
        VivoxOutputDeviceVPS result = new VivoxOutputDeviceVPS();
        try
        {
            if (isInitialized == false)
            {
                Debug.Log("Vivox is not initialized yet !");
                return result;
            }

            var device_ = VivoxService.Instance.ActiveOutputDevice;

            result.Device = device_;
            result.DeviceID = device_.DeviceID;
            result.DeviceName = device_.DeviceName;

            return result;
        }
        catch (Exception ex)
        {
            Debug.Log("Get active output device error :" + ex.ToString());
            return result;
        }


    }

    public List<string> GetActiveChannels()
    {
        List<string> result = new List<string>();
        try
        {
            if (isLoggedIn == false)
            {
                Debug.Log("Need to sign in first !");
                return result;
            }

            var channels_ = VivoxService.Instance.ActiveChannels;
            foreach ( var channel in channels_)
            {
                result.Add(channel.Key);
            }
            
            return result;
        }
        catch (Exception ex)
        {
            Debug.Log("Get active channels error :" + ex.ToString());
            return result;
        }


    }

    public double GetMyAudioEnergy()
    {
        double result = 0;
        try
        {
            if (AlreadyJoinedChannel() == false)
            {
                return 0;
            }

            result = MyParticipant.GetAudioEnergy();
            
            return result;
        }
        catch
        {
            return 0;
        }


    }
    #endregion


}

public enum VivoxRoomTypeVPS
{
    TextOnly,
    AudioOnly,
    TextAndAudio
}

public enum VivoxRoomVoiceVPS
{
    AudioOnly,
    TextAndAudio
}
public struct VivoxUserVPS
{
    public string DisplayName;
    public string UserID;
    public bool isMuted;
    public bool isSpeaking;
}

public struct VivoxMessageVPS
{
    public string ChannelName;
    public string SenderID;
    public string SenderName;
    public string MessageID;
    public string MessageText;
    public DateTime ReceivedTime;
}

public struct VivoxInputDeviceVPS
{
    public VivoxInputDevice Device;
    public string DeviceID;
    public string DeviceName;
}

public struct VivoxOutputDeviceVPS
{
    public VivoxOutputDevice Device;
    public string DeviceID;
    public string DeviceName;
}