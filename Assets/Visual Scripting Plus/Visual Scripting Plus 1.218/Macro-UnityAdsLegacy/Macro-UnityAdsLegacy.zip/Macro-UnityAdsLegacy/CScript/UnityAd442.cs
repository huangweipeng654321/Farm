using UnityEngine;
using UnityEngine.Advertisements;
using UnityEngine.Events;
using Unity.VisualScripting;

public class UnityAd442 : MonoBehaviour, IUnityAdsInitializationListener, IUnityAdsLoadListener, IUnityAdsShowListener
{
    [Header("Settings")]
    [SerializeField] string GameIdAndroid = "4284671";
    [SerializeField] string GameIdIOS = "4284672";
    [SerializeField] bool TestMode = false;
    [SerializeField] private BannerPosition bannerPosition = BannerPosition.BOTTOM_CENTER;

    [Header("Placement Ads ID")]
    [SerializeField] string PlacementIdBannerAndroid = "Banner_Android";
    [SerializeField] string PlacementIdBannerIOS = "Banner_iOS";
    [SerializeField] string PlacementIdInterstitialAndroid = "Interstitial_Android";
    [SerializeField] string PlacementIdInterstitialIOS = "Interstitial_iOS";
    [SerializeField] string PlacementIdRewardAdAndroid = "Rewarded_Android";
    [SerializeField] string PlacementIdRewardAdIOS = "Rewarded_iOS";

    private string _gameId;
    private int platform_ = 0; //0= Unity Editor , 1=Android, 2=iOS

    private bool _isBannerLoaded = false;
    private bool _isRewardAdLoaded = false;

    private string PlacementIdBanner = "Banner_Android";
    private string PlacementIdInterstital = "Interstitial_Android";
    private string PlacementIdRewardAd = "Rewarded_Android";

    [Header("[Read Only]")]
    //Visual Scripting Trigger Initilized
    

    private GameObject MacroUnityAds;
    void Awake()
    {
        MacroUnityAds = GameObject.Find("Macro-UnityAdsLegacy");
        if (Application.isMobilePlatform)
        {
            if (Application.platform == RuntimePlatform.Android)
            {
                platform_ = 1;
            }
            else
            {
                platform_ = 2;
            }

        }
        else
        {
            platform_ = 0;
        }
        PreloadAdUnit();
    }
    
    private void PreloadAdUnit()
    {
        if (platform_ == 0 || platform_ == 1)
        {
            _gameId = GameIdAndroid;
            PlacementIdBanner = PlacementIdBannerAndroid;
            PlacementIdInterstital = PlacementIdInterstitialAndroid;
            PlacementIdRewardAd = PlacementIdRewardAdAndroid;
        }
        else
        {
            _gameId = GameIdIOS;
            PlacementIdBanner = PlacementIdBannerIOS;
            PlacementIdInterstital = PlacementIdInterstitialIOS;
            PlacementIdRewardAd = PlacementIdRewardAdIOS;
        }

        Advertisement.Banner.SetPosition(bannerPosition);
    }
    public void InitializeAds()
    {
        if (!Advertisement.isInitialized && Advertisement.isSupported)
        {
            Advertisement.Initialize(_gameId, TestMode, this);
        }
    }

    public void OnInitializationComplete()
    {
        Debug.Log("Unity Ads initialization complete.");
        CustomEvent.Trigger(MacroUnityAds, "Trigger_Initial_Success");
    }

    public void OnInitializationFailed(UnityAdsInitializationError error, string message)
    {
        Debug.Log("Unity Ads Initialization Failed");

        CustomEvent.Trigger(MacroUnityAds, "Trigger_Initial_Failed");
    }

    public bool isAdInitialized()
    {
        return Advertisement.isInitialized;
    }

    //
    // Finish Initialize
    //

    //
    // Banner
    //
    public void LoadBanner()
    {
        Debug.Log("Banner loading");
        // Set up options to notify the SDK of load events:
        BannerLoadOptions options = new BannerLoadOptions
        {
            loadCallback = OnBannerLoaded,
            errorCallback = OnBannerError
        };

        // Load the Ad Unit with banner content:
        Advertisement.Banner.Load(PlacementIdBanner, options);
    }

    public void OnBannerLoaded()
    {
        _isBannerLoaded = true;
        Debug.Log("Banner loaded");
        Variables.Application.Set("AdsLegacy-BannerShowing", false);

        CustomEvent.Trigger(MacroUnityAds, "Trigger_Banner_Loaded");
    }

    public bool isBannerLoaded()
    {
        return _isBannerLoaded;
    }

    public void OnBannerError(string message)
    {
        Debug.Log("Banner load Error");

        CustomEvent.Trigger(MacroUnityAds, "Trigger_Banner_Error");

    }

    public void ShowBannerAd()
    {
        Debug.Log("Banner Showing");
        // Set up options to notify the SDK of show events:
        BannerOptions options = new BannerOptions
        {
            clickCallback = OnBannerClicked,
            hideCallback = OnBannerHidden,
            showCallback = OnBannerShown
        };

        // Show the loaded Banner Ad Unit:
        Advertisement.Banner.Show(PlacementIdBanner, options);
    }

    public void HideBannerAd()
    {
        if (!Variables.Application.IsDefined("AdsLegacy-BannerShowing"))
        {
            Debug.Log("Not Get Banner yet");
        }
        // Hide the banner:
        Debug.Log("Banner is hiding");
        Advertisement.Banner.Hide();

    }

    public void OnBannerClicked()
    {
        Debug.Log("Banner is clicked");
        
        CustomEvent.Trigger(MacroUnityAds, "Trigger_Banner_Clicked");
    }
    public void OnBannerShown()
    {
        Debug.Log("Banner is showed");
        Variables.Application.Set("AdsLegacy-BannerShowing", true);

        CustomEvent.Trigger(MacroUnityAds, "Trigger_Banner_Showed");
    }
    public void OnBannerHidden()
    {
        Debug.Log("Banner is hidden");
        if (!Variables.Application.IsDefined("AdsLegacy-BannerShowing"))
        {
            Debug.Log("Did not create Banner View yet");
        }
        else
        {
            Variables.Application.Set("AdsLegacy-BannerShowing", false);
        }

        CustomEvent.Trigger(MacroUnityAds, "Trigger_Banner_Hidden");
    }


    public void SetBannerPosition(int position_)
    {
        if (position_ == 0)
        {
            Advertisement.Banner.SetPosition(BannerPosition.TOP_LEFT);
        }
        if (position_ == 1)
        {
            Advertisement.Banner.SetPosition(BannerPosition.TOP_CENTER);
        }
        if (position_ == 2)
        {
            Advertisement.Banner.SetPosition(BannerPosition.TOP_RIGHT);
        }
        if (position_ == 3)
        {
            Advertisement.Banner.SetPosition(BannerPosition.BOTTOM_LEFT);
        }
        if (position_ == 4)
        {
            Advertisement.Banner.SetPosition(BannerPosition.BOTTOM_CENTER);
        }
        if (position_ == 5)
        {
            Advertisement.Banner.SetPosition(BannerPosition.BOTTOM_RIGHT);
        }
        if (position_ == 6)
        {
            Advertisement.Banner.SetPosition(BannerPosition.CENTER);
        }
    }
    //
    // Banner END
    //

    //
    // Rewarded Ad
    //
    public void LoadRewardedAd()
    {
        Debug.Log("Rewarded Ad is loading");
        Advertisement.Load(PlacementIdRewardAd, this);
    }

    public bool isRewardAdLoaded()
    {
        return _isRewardAdLoaded;
    }

    public void OnUnityAdsAdLoaded(string adUnitId)
    {
        _isRewardAdLoaded = true;

        if (adUnitId.Equals(PlacementIdRewardAd))
        {
            CustomEvent.Trigger(MacroUnityAds, "Trigger_Reward_OnLoaded");
        }
        Debug.Log("Rewarded Ad is loaded");
    }

    public void ShowRewardedAd()
    {
        Debug.Log("Rewarded Ad is showing");
        Advertisement.Show(PlacementIdRewardAd, this);
    }

    public void OnUnityAdsShowComplete(string adUnitId, UnityAdsShowCompletionState showCompletionState)
    {
        Debug.Log("Rewarded Ad is closed");
        if (adUnitId.Equals(PlacementIdRewardAd) && showCompletionState.Equals(UnityAdsShowCompletionState.COMPLETED))
        {
            // Grant a reward.
            CustomEvent.Trigger(MacroUnityAds, "Trigger_Reward_OnGranted");
        }
    }

    // Implement Load and Show Listener error callbacks:
    public void OnUnityAdsFailedToLoad(string adUnitId, UnityAdsLoadError error, string message)
    {
        Debug.Log("Rewarded Ad failed to load");
        if (adUnitId.Equals(PlacementIdRewardAd))
        {
            CustomEvent.Trigger(MacroUnityAds, "Trigger_Reward_OnLoadFailed");
        }

    }

    public void OnUnityAdsShowFailure(string adUnitId, UnityAdsShowError error, string message)
    {
        Debug.Log("Rewarded Ad failed to show");
        if (adUnitId.Equals(PlacementIdRewardAd))
        {

            CustomEvent.Trigger(MacroUnityAds, "Trigger_Reward_ShowFailed");
        }

    }
    public void OnUnityAdsShowStart(string adUnitId)
    {
        Debug.Log("Rewarded Ad started");
        if (adUnitId.Equals(PlacementIdRewardAd))
        {
            CustomEvent.Trigger(MacroUnityAds, "Trigger_Reward_OnStart");
        }
    }
    public void OnUnityAdsShowClick(string adUnitId)
    {
        Debug.Log("Rewarded Ad is clicked");
        if (adUnitId.Equals(PlacementIdRewardAd))
        {
            CustomEvent.Trigger(MacroUnityAds, "Trigger_Reward_OnClicked");
        }
    }
    //
    // Rewarded End
    //

    //
    // Interstital Begin
    //
    public void LoadInterstitalAd()
    {
        // IMPORTANT! Only load content AFTER initialization (in this example, initialization is handled in a different script).
        Debug.Log("Loading Ad: " + PlacementIdInterstital);
        Advertisement.Load(PlacementIdInterstital, this);
    }
    
    // Show the loaded content in the Ad Unit:
    public void ShowInterstitalAd()
    {
        // Note that if the ad content wasn't previously loaded, this method will fail
        Debug.Log("Showing Ad: " + PlacementIdInterstital);
        Advertisement.Show(PlacementIdInterstital, this);
    }

    // Implement Load Listener and Show Listener interface methods: 
    public void OnUnityAdsInterstitalAdLoaded(string adUnitId)
    {
        Debug.Log("Interstital Ad is Loaded");
        CustomEvent.Trigger(MacroUnityAds, "Trigger_Interstital_OnLoaded");

    }
    
    public void OnUnityAdsInterstitalFailedToLoad(string _adUnitId, UnityAdsLoadError error, string message)
    {
        Debug.Log("Error loading Interstital Ad Unit ");
        // Optionally execute code if the Ad Unit fails to load, such as attempting to try again.
        
        CustomEvent.Trigger(MacroUnityAds, "Trigger_Interstital_OnLoadFailed");
    }

    public void OnUnityAdsInterstitalShowFailure(string _adUnitId, UnityAdsShowError error, string message)
    {
        Debug.Log("Error showing Interstital Ad Unit");
        // Optionally execute code if the Ad Unit fails to show, such as loading another ad.
        CustomEvent.Trigger(MacroUnityAds, "Trigger_Interstital_ShowFailed");
    }

    public void OnUnityAdsInterstitalShowStart(string _adUnitId) 
    { 
        Debug.Log("Interstital Ad Show Start");
        CustomEvent.Trigger(MacroUnityAds, "Trigger_Interstital_OnStart");
    }
    public void OnUnityAdsInterstitalShowClick(string _adUnitId) 
    {
        Debug.Log("Interstital Ad Show Click");
        CustomEvent.Trigger(MacroUnityAds, "Trigger_Interstital_OnClicked");
    }
    public void OnUnityAdsInterstitalShowComplete(string _adUnitId, UnityAdsShowCompletionState showCompletionState) 
    {
        Debug.Log("Interstital Ad Show Complete");
        CustomEvent.Trigger(MacroUnityAds, "Trigger_Interstital_OnComplete");
    }
}
