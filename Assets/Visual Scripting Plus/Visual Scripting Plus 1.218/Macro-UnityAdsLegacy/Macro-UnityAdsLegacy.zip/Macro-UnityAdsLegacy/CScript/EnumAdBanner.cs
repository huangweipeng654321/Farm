using UnityEngine;

public class EnumAdBanner : MonoBehaviour
{
    public enum VS_BannerPosition
    {
        TOP_LEFT,
        TOP_CENTER,
        TOP_RIGHT,
        BOTTOM_LEFT,
        BOTTOM_CENTER,
        BOTTOM_RIGHT,
        CENTER
    };
}
