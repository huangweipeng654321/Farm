using UnityEngine;
using GoogleMobileAds.Api;
using Unity.VisualScripting;
using System;
using System.Collections;

public class AdmobManagerVS : MonoBehaviour
{

    private string Banner_Id_Admob = "ca-app-pub-3940256099942544/6300978111";
    private string Interstitial_Id_Admob = "ca-app-pub-3940256099942544/1033173712";
    private string Rewarded_Id_Admob = "ca-app-pub-3940256099942544/5224354917";

    [Header("Settings")]
    [SerializeField] public AdPosition bannerPosition = AdPosition.Top; //Banner Position

    [Header("Android Ads ID")]
    [SerializeField] string Banner_AdId_Android = "ca-app-pub-3940256099942544/6300978111";
    [SerializeField] string Interstial_AdId_Android = "ca-app-pub-3940256099942544/1033173712";
    [SerializeField] string Rewarded_AdId_Android = "ca-app-pub-3940256099942544/5224354917";

    [Header("iOS Ads ID")]
    [SerializeField] string Banner_AdId_iOS = "ca-app-pub-3940256099942544/2934735716";
    [SerializeField] string Interstial_AdId_iOS = "ca-app-pub-3940256099942544/4411468910";
    [SerializeField] string Rewarded_AdId_iOS = "ca-app-pub-3940256099942544/1712485313";

    // Init
    private int platform_ = 0; //0= Unity Editor , 1=Android, 2=iOS
    private bool isInitialized = false;
    private int LimitAdInitTime = 0;

    //Rewarded Ad
    private RewardedAd _rewardedAd;
    private bool isRewadedLoaded = false;
    //Interstitial
    private bool isInterstitialLoaded = false;
    private InterstitialAd _interstitialAd;
    //Banner
    private bool isBannerLoaded = false;
    private BannerView _bannerView;
    private AdSize BannerAdSize_ = AdSize.Banner; //Banner size

    [Header("[Read Only]")]
    //Trigger to Visual Scripting
    

    private GameObject MacroAdmob;
    void Awake()
    {
        MacroAdmob = GameObject.Find("Macro-Admob");
        if (Application.isMobilePlatform)
        {
            if (Application.platform == RuntimePlatform.Android)
            {
                platform_ = 1;
            }
            else
            {
                platform_ = 2;
            }

        }
        else
        {
            platform_ = 0;
        }
        PreloadAdUnit();
    }

    private void PreloadAdUnit()
    {
        if (platform_ == 0 || platform_ == 1)
        {
            Banner_Id_Admob = Banner_AdId_Android;
            Interstitial_Id_Admob = Interstial_AdId_Android;
            Rewarded_Id_Admob = Rewarded_AdId_Android;
        }
        else
        {
            Banner_Id_Admob = Banner_AdId_iOS;
            Interstitial_Id_Admob = Interstial_AdId_iOS;
            Rewarded_Id_Admob = Rewarded_AdId_iOS;
        }
    }
    //
    // Start Ads Initialize
    //
    public void StartAdMobInitialize()
    {
        if (isInitialized == false)
        {
            MobileAds.Initialize((InitializationStatus initStatus) =>
            {
                //Visual Scripting Trigger
                
                CustomEvent.Trigger(MacroAdmob, "Trigger_Is_Initialized");
                isInitialized = true;
                Debug.Log("Confirmed Ad Initialized Done !");
            });
            //recheck Ad Init value to make sure it is Initilized
            StartCoroutine(RecheckAdInitialize());
        }
    }

    IEnumerator RecheckAdInitialize()
    {
        yield return new WaitForSeconds(5);
        if (isInitialized == false)
        {
            if (LimitAdInitTime < 3)
            {
                LimitAdInitTime++;
                Debug.Log("Ad Initialize again");
                StartAdMobInitialize();
            }
        }
    }

    public bool isAdsInitialized()
    {
        return isInitialized;
    }

    public void SetAdId(string banner_id, string interstitial_id, string rewarded_id)
    {
        Banner_Id_Admob = banner_id;
        Interstitial_Id_Admob = interstitial_id;
        Rewarded_Id_Admob = rewarded_id;
    }

    //
    // End Ads Initialize
    //

    //
    // Start Banner
    //
    public bool isBannerLoadedYet()
    {
        return isBannerLoaded;
    }
    public void LoadBannerAd()
    {
        if (_bannerView == null)
        {
            CreateBannerView();
        }

        // Create our request used to load the ad.
        var adRequestBanner = new AdRequest();

        // Send the request to load the ad.
        Debug.Log("Loading banner ad.");
        _bannerView.LoadAd(adRequestBanner);
    }
    //to add Listener action everytime it's triggered
    // How to use Delegate : www.gamedeveloper.com/programming/how-to-use-c-delegates-in-unity

    private void ListenToAdEvents()
    {
        
        // Raised when an ad is loaded into the banner view.
        _bannerView.OnBannerAdLoaded += () =>
        {
            Debug.Log("Banner view loaded");
            isBannerLoaded = true;
            
            CustomEvent.Trigger(MacroAdmob, "Trigger_Banner_Is_Loaded");

        };
        // Raised when an ad fails to load into the banner view.
        _bannerView.OnBannerAdLoadFailed += (LoadAdError error) =>
        {
            Debug.Log("Banner view failed to load an ad with error ");
            
            CustomEvent.Trigger(MacroAdmob, "Trigger_Banner_Fail_Loaded");
        };
        // Raised when the ad is estimated to have earned money.
        _bannerView.OnAdPaid += (AdValue adValue) =>
        {
            Debug.Log(String.Format("Banner view paid."));
            
            CustomEvent.Trigger(MacroAdmob, "Trigger_Banner_OnAdPaid");
        };
        // Raised when an impression is recorded for an ad.
        _bannerView.OnAdImpressionRecorded += () =>
        {
            Debug.Log("Banner view recorded an impression.");
            
            CustomEvent.Trigger(MacroAdmob, "Trigger_Banner_OnAdImpressionRecorded");
        };
        // Raised when a click is recorded for an ad.
        _bannerView.OnAdClicked += () =>
        {
            Debug.Log("Banner view was clicked.");
            
            CustomEvent.Trigger(MacroAdmob, "Trigger_Banner_OnAdClicked");
        };
        // Raised when an ad opened full screen content.
        _bannerView.OnAdFullScreenContentOpened += () =>
        {
            Debug.Log("Banner view full screen content opened.");
            
            CustomEvent.Trigger(MacroAdmob, "Trigger_Banner_OnAdFullScreenContentOpened");
        };
        // Raised when the ad closed full screen content.
        _bannerView.OnAdFullScreenContentClosed += () =>
        {
            Debug.Log("Banner view full screen content closed.");
            
            CustomEvent.Trigger(MacroAdmob, "Trigger_Banner_OnAdFullScreenContentClosed");
        };
    }

    public void HideBannerAd()
    {
        if (_bannerView != null)
        {
            _bannerView.Hide();
        }
    }


    public void ShowBannerAd()
    {
        //Banner must be Loaded first
        if (_bannerView != null)
        {
            _bannerView.Show();
        }
    }

    public void CreateBannerView()
    {
        // If we already have a banner, destroy the old one.
        if (_bannerView != null)
        {
            DestroyBannerView();
        }

        // Create a 320x50 banner at top of the screen
        _bannerView = new BannerView(Banner_Id_Admob, BannerAdSize_, bannerPosition);

        // Listen to events the banner may raise.
        ListenToAdEvents();

        Debug.Log("Banner view created.");
    }

    public void DestroyBannerView()
    {
        if (_bannerView != null)
        {
            //RemoveEventHandlersBanner();
            _bannerView.Destroy();
            _bannerView = null;
            isBannerLoaded = false;
        }
    }

    public void SetBannerAdSize(string name_)
    {
        if (name_ == "Banner")
        {
            BannerAdSize_ = AdSize.Banner;
        }
        if (name_ == "IABBanner")
        {
            BannerAdSize_ = AdSize.IABBanner;
        }
        if (name_ == "Leaderboard")
        {
            BannerAdSize_ = AdSize.Leaderboard;
        }
        if (name_ == "MediumRectangle")
        {
            BannerAdSize_ = AdSize.MediumRectangle;
        }
    }

    public void SetBannerPosition(string position)
    {
        if (position == "Bottom")
        {
            bannerPosition = AdPosition.Bottom;
        }
        if (position == "BottomLeft")
        {
            bannerPosition = AdPosition.BottomLeft;
        }
        if (position == "BottomRight")
        {
            bannerPosition = AdPosition.BottomRight;
        }
        if (position == "Center")
        {
            bannerPosition = AdPosition.Center;
        }
        if (position == "Top")
        {
            bannerPosition = AdPosition.Top;
        }
        if (position == "TopLeft")
        {
            bannerPosition = AdPosition.TopLeft;
        }
        if (position == "TopRight")
        {
            bannerPosition = AdPosition.TopRight;
        }
    }


    //
    // End Banner
    //

    //
    // Start Rewarded Video
    //
    public void LoadRewardedAd()
    {
        // Clean up the old ad before loading a new one.
        DestroyRewardedAd();

        // After Ad is closed, RewardAd Video will be destroyed, var isRewadGranted is destroyed.
        //isRewadGranted = false;
        Variables.Application.Set("Ads-RewardGranted", false);
        isRewadedLoaded = false;
        
        var adRequestRewarded = new AdRequest();
        
        RewardedAd.Load(Rewarded_Id_Admob, adRequestRewarded, (RewardedAd ad, LoadAdError error) =>
        {


            // If the operation failed with a reason.
            if (error != null)
            {
                isRewadedLoaded = false;
                Debug.Log("Rewarded ad failed to load an ad with error ");

                
                CustomEvent.Trigger(MacroAdmob, "Trigger_Rewarded_Fail_Loaded");
                return;
            }
            // If the operation failed for unknown reasons.
            // This is an unexpected error, please report this bug if it happens.
            if (ad == null)
            {
                isRewadedLoaded = false;
                Debug.Log("Unexpected error: Rewarded load event fired with null ad and null error.");

                CustomEvent.Trigger(MacroAdmob, "Trigger_Rewarded_Fail_Loaded");
                return;
            }

            // The operation completed successfully.
            isRewadedLoaded = true;
            Debug.Log("Rewarded ad loaded ");
            _rewardedAd = ad;
            
            CustomEvent.Trigger(MacroAdmob, "Trigger_Rewarded_On_Loaded");
            // Register to ad events to extend functionality.
            //RegisterEventHandlers(_rewardedAd);

        });
    }

    
    public void ReloadRewardedAdAfterShow()
    {
        DestroyRewardedAd();

        
        Variables.Application.Set("Ads-RewardGranted", false);
        isRewadedLoaded = false;

        var adRequestRewarded = new AdRequest();

        //(RewardedAd ad, LoadAdError error) will add Listerner everytime RewardedAd.Load called...
        RewardedAd.Load(Rewarded_Id_Admob, adRequestRewarded, (RewardedAd ad, LoadAdError error) =>
        {
            
            // If the operation failed with a reason.
            if (error != null)
            {
                isRewadedLoaded = false;
                Debug.Log("Rewarded ad failed to load an ad with error ");

                return;
            }
            // If the operation failed for unknown reasons.
            // This is an unexpected error, please report this bug if it happens.
            if (ad == null)
            {
                isRewadedLoaded = false;
                Debug.Log("Unexpected error: Rewarded load event fired with null ad and null error.");
                
                return;
            }

            // The operation completed successfully.
            isRewadedLoaded = true;
            _rewardedAd = ad;

            Debug.Log("Rewarded ad RELOADED : This will not trigger again [On Reward Ad Loaded] ");
            
            
        });
    }
    

    public bool isRewadedLoadedValue()
    {
        return isRewadedLoaded;
    }
    public void ResetRewardGranted()
    {
        isRewadedLoaded = false;
        Variables.Application.Set("Ads-RewardGranted", false);
    }

    public void ShowRewardedAd()
    {
        if (_rewardedAd != null && _rewardedAd.CanShowAd())
        {
            RegisterEventHandlers(_rewardedAd);
            
            //....
            _rewardedAd.Show((Reward reward) =>
            {
                // TODO: Reward the user.
                Variables.Application.Set("Ads-RewardGranted", true);
                
                CustomEvent.Trigger(MacroAdmob, "Trigger_Rewarded_Get_Reward");
            });
        }
    }


    public void DestroyRewardedAd()
    {
        if (_rewardedAd != null)
        {
            _rewardedAd.Destroy();
            _rewardedAd = null;
            isRewadedLoaded = false;
        }
    }


    private void RegisterEventHandlers(RewardedAd ad)
    {
        
        ad.OnAdPaid += (AdValue adValue) =>
        {
            Debug.Log(String.Format("Rewarded ad paid"));
            
            CustomEvent.Trigger(MacroAdmob, "Trigger_Rewarded_Ad_OnAdPaid");
        };
        // Raised when an impression is recorded for an ad.
        ad.OnAdImpressionRecorded += () =>
        {
            Debug.Log("Rewarded ad recorded an impression.");
            
            CustomEvent.Trigger(MacroAdmob, "Trigger_Rewarded_Ad_OnAdImpressionRecorded");
        };
        
            
        // Raised when a click is recorded for an ad.
        ad.OnAdClicked += () =>
        {
            Debug.Log("Rewarded ad was clicked.");
            CustomEvent.Trigger(MacroAdmob, "Trigger_Rewarded_Ad_OnAdClicked");
        };
        // Raised when the ad opened full screen content.

        ad.OnAdFullScreenContentOpened += () =>
        {

            Debug.Log("Rewarded ad full screen content opened.");
            CustomEvent.Trigger(MacroAdmob, "Trigger_Rewarded_Ad_OnAdFullScreenContentOpened");

        };

       
        ad.OnAdFullScreenContentClosed += () =>
        {
            Debug.Log("Rewarded ad full screen content closed.");
            CustomEvent.Trigger(MacroAdmob, "Trigger_Rewarded_Ad_Closed");
        };
        
        // Raised when the ad failed to open full screen content.
        ad.OnAdFullScreenContentFailed += (AdError error) =>
        {
            Debug.Log("Rewarded ad failed to open full screen content with error ");
            CustomEvent.Trigger(MacroAdmob, "Trigger_Rewarded_Show_Failed");
        };

    }

    //
    // Interstital Ad Start
    //
    public void DestroyInterstitialAd()
    {
        if (_interstitialAd != null)
        {
            Debug.Log("Destroying interstitial ad.");
            _interstitialAd.Destroy();
            _interstitialAd = null;
            isInterstitialLoaded = false;
        }

    }
    public bool isInterstitalLoadedValue()
    {
        return isInterstitialLoaded;
    }
    public void LoadInterstitialAd()
    {
        // Clean up the old ad before loading a new one.
        if (_interstitialAd != null)
        {
            DestroyInterstitialAd();
        }

        Debug.Log("Loading interstitial ad.");
        isInterstitialLoaded = false;
        // Create our request used to load the ad.
        var adRequest = new AdRequest();

        // Send the request to load the ad.
        InterstitialAd.Load(Interstitial_Id_Admob, adRequest, (InterstitialAd ad, LoadAdError error) =>
        {
            // If the operation failed with a reason.
            if (error != null)
            {
                isInterstitialLoaded = false;
                Debug.Log("Interstitial ad failed to load an ad with error ");
                CustomEvent.Trigger(MacroAdmob, "Trigger_InterstitialAd_Fail_Loaded");
                return;
            }
            // If the operation failed for unknown reasons.
            // This is an unexpected error, please report this bug if it happens.
            if (ad == null)
            {
                isInterstitialLoaded = false;
                Debug.Log("Unexpected error: Interstitial load event fired with null ad and null error.");
                CustomEvent.Trigger(MacroAdmob, "Trigger_InterstitialAd_Fail_Loaded");
                return;
            }

            // The operation completed successfully.
            Debug.Log("Interstitial ad loaded");
            isInterstitialLoaded = true;
            _interstitialAd = ad;

            // Register to ad events to extend functionality.
            
            CustomEvent.Trigger(MacroAdmob, "Trigger_InterstitialAd_On_Loaded");
        });
    }

    public void ReloadInterstitalAdAfterShow()
    {
        // Clean up the old ad before loading a new one.
        if (_interstitialAd != null)
        {
            DestroyInterstitialAd();
        }

        Debug.Log("Loading interstitial ad.");
        isInterstitialLoaded = false;
        // Create our request used to load the ad.
        var adRequest = new AdRequest();

        InterstitialAd.Load(Interstitial_Id_Admob, adRequest, (InterstitialAd ad, LoadAdError error) =>
        {
            // If the operation failed with a reason.
            if (error != null)
            {
                isInterstitialLoaded = false;
                Debug.Log("Interstitial ad failed to load an ad with error ");
                return;
            }
            if (ad == null)
            {
                isInterstitialLoaded = false;
                Debug.Log("Unexpected error: Interstitial load event fired with null ad and null error.");
                return;
            }

            // The operation completed successfully.
            Debug.Log("Interstitial ad RELOADED : This will not trigger again [On Interstitial Ad Loaded] ");
            _interstitialAd = ad;
            isInterstitialLoaded = true;
        });
    }

    public void ShowInterstialAd()
    {
        if (_interstitialAd != null && _interstitialAd.CanShowAd())
        {
            RegisterEventHandlersInterstital(_interstitialAd);
            Debug.Log("Showing interstitial ad.");
            _interstitialAd.Show();
        }
        else
        {
            Debug.Log("Interstitial ad is not ready yet.");
            CustomEvent.Trigger(MacroAdmob, "Trigger_InterstitialAd_Show_Failed");
        }

    }
    
    private void RegisterEventHandlersInterstital(InterstitialAd ad)
    {
        // Raised when the ad is estimated to have earned money.
        ad.OnAdPaid += (AdValue adValue) =>
        {
            Debug.Log("Interstitial ad paid");
            CustomEvent.Trigger(MacroAdmob, "Trigger_InterstitialAd_OnAdPaid");
        };
        // Raised when an impression is recorded for an ad.
        ad.OnAdImpressionRecorded += () =>
        {
            Debug.Log("Interstitial ad recorded an impression.");
            CustomEvent.Trigger(MacroAdmob, "Trigger_InterstitialAd_OnImpression");
        };
        // Raised when a click is recorded for an ad.
        ad.OnAdClicked += () =>
        {
            Debug.Log("Interstitial ad was clicked.");
            CustomEvent.Trigger(MacroAdmob, "Trigger_InterstitialAd_OnClicked");
        };
        // Raised when an ad opened full screen content.
        ad.OnAdFullScreenContentOpened += () =>
        {
            Debug.Log("Interstitial ad full screen content opened.");
            CustomEvent.Trigger(MacroAdmob, "Trigger_InterstitialAd_OnOpened");
        };
        // Raised when the ad closed full screen content.
        ad.OnAdFullScreenContentClosed += () =>
        {
            Debug.Log("Interstitial ad full screen content closed.");
            CustomEvent.Trigger(MacroAdmob, "Trigger_InterstitialAd_OnClosed");
        };
        // Raised when the ad failed to open full screen content.
        ad.OnAdFullScreenContentFailed += (AdError error) =>
        {
            Debug.Log("Interstitial ad failed to open full screen content with error");
            CustomEvent.Trigger(MacroAdmob, "Trigger_InterstitialAd_Show_Failed");
        };
    }
}