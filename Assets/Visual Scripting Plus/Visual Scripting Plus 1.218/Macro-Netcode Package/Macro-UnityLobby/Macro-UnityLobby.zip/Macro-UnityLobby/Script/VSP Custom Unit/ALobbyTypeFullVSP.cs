using System.Collections.Generic;
using Unity.Services.Lobbies.Models;
using Unity.VisualScripting;

[UnitTitle("Create A Lobby type full info")]
[UnitCategory("Custom/Visual Scripting Plus")]
public class ALobbyTypeFullVSP : Unit
{
    // Input ports
    private ValueInput aLobby;

    // Output port
    private ValueOutput LobbyID;
    private ValueOutput HostID;
    private ValueOutput Password;
    private ValueOutput MaxPlayers;
    private ValueOutput AvailableSlots;
    private ValueOutput isPrivate;
    private ValueOutput isLocked;
    private ValueOutput SearchRegion;
    private ValueOutput SearchLobbyName;
    private ValueOutput SearchGameMode;
    private ValueOutput SearchExtraMode;
    private ValueOutput SearchRankMin;
    private ValueOutput SearchRankMax;
    private ValueOutput SearchLevelMin;
    private ValueOutput SearchLevelMax;
    private ValueOutput SearchExtraNumber;
    private ValueOutput LobbyMembersID;
    private ValueOutput LobbyClientsID;
    private ValueOutput ConnectedClientsID;

    protected override void Definition()
    {
        //  Input
        aLobby = ValueInput<LobbyInfo_VSP>("A Lobby");

        //  Output
        LobbyID = ValueOutput<string>("Lobby ID", (flow) =>
        {
            string val1 = flow.GetValue<LobbyInfo_VSP>(aLobby).Id;
            return val1;
        });

        HostID = ValueOutput<string>("Host ID", (flow) =>
        {
            string val2 = flow.GetValue<LobbyInfo_VSP>(aLobby).HostId;
            return val2;
        });

        Password = ValueOutput<string>("Password", (flow) =>
        {
            string val3 = flow.GetValue<LobbyInfo_VSP>(aLobby).LobbyPassword;
            return val3;
        });

        MaxPlayers = ValueOutput<int>("Max Players", (flow) =>
        {
            int val4 = flow.GetValue<LobbyInfo_VSP>(aLobby).MaxPlayers;
            return val4;
        });

        AvailableSlots = ValueOutput<int>("Available Slots", (flow) =>
        {
            int val5 = flow.GetValue<LobbyInfo_VSP>(aLobby).AvailableSlots;
            return val5;
        });

        isLocked = ValueOutput<bool>("is Locked", (flow) =>
        {
            bool val6 = flow.GetValue<LobbyInfo_VSP>(aLobby).IsLocked;
            return val6;
        });

        isPrivate = ValueOutput<bool>("is Private", (flow) =>
        {
            bool val7 = flow.GetValue<LobbyInfo_VSP>(aLobby).IsPrivate;
            return val7;
        });

        SearchRegion = ValueOutput<string>("Search Region", (flow) =>
        {
            string val8 = flow.GetValue<LobbyInfo_VSP>(aLobby).Region;
            return val8;
        });

        SearchLobbyName = ValueOutput<string>("Search Lobby Name", (flow) =>
        {
            string val9 = flow.GetValue<LobbyInfo_VSP>(aLobby).Name;
            return val9;
        });

        SearchGameMode = ValueOutput<string>("Search Game Mode", (flow) =>
        {
            string val10 = flow.GetValue<LobbyInfo_VSP>(aLobby).GameMode;
            return val10;
        });

        SearchExtraMode = ValueOutput<string>("Search Extra Mode", (flow) =>
        {
            string val11 = flow.GetValue<LobbyInfo_VSP>(aLobby).ExtraMode;
            return val11;
        });

        SearchRankMin = ValueOutput<string>("Search Rank Min", (flow) =>
        {
            string val12 = flow.GetValue<LobbyInfo_VSP>(aLobby).RankMin;
            return val12;
        });

        SearchRankMax = ValueOutput<string>("Search Rank Max", (flow) =>
        {
            string val13 = flow.GetValue<LobbyInfo_VSP>(aLobby).RankMax;
            return val13;
        });

        SearchLevelMin = ValueOutput<string>("Search Level Min", (flow) =>
        {
            string val14 = flow.GetValue<LobbyInfo_VSP>(aLobby).LevelMin;
            return val14;
        });

        SearchLevelMax = ValueOutput<string>("Search Level Max", (flow) =>
        {
            string val15 = flow.GetValue<LobbyInfo_VSP>(aLobby).LevelMax;
            return val15;
        });

        SearchExtraNumber = ValueOutput<string>("Search Extra Number", (flow) =>
        {
            string val16 = flow.GetValue<LobbyInfo_VSP>(aLobby).ExtraNumber;
            return val16;
        });

        LobbyMembersID = ValueOutput<List<string>>("Lobby Members ID", (flow) =>
        {
            var membersList = flow.GetValue<LobbyInfo_VSP>(aLobby);
            return membersList.Members;
        });

        LobbyClientsID = ValueOutput<List<string>>("Lobby Clients ID", (flow) =>
        {
            var membersList = flow.GetValue<LobbyInfo_VSP>(aLobby);
            return membersList.Clients;
        });

        ConnectedClientsID = ValueOutput<List<string>>("Connected Clients ID", (flow) =>
        {
            var membersList = flow.GetValue<LobbyInfo_VSP>(aLobby);
            return membersList.ClientsConnected;
        });
    }
}
