using Unity.VisualScripting;

[UnitTitle("Create A Lobby type short info")]
[UnitCategory("Custom/Visual Scripting Plus")]
public class ALobbyTypeShortVSP : Unit
{
    // Input ports
    private ValueInput aLobby;

    // Output port
    private ValueOutput LobbyID;
    private ValueOutput isLocked;
    protected override void Definition()
    {
        //  Input
        aLobby = ValueInput<LobbyInfo_VSP>("A Lobby");

        //  Output
        LobbyID = ValueOutput<string>("Lobby ID", (flow) =>
        {
            string valA = flow.GetValue<LobbyInfo_VSP>(aLobby).Id;
            return valA;
        });

        isLocked = ValueOutput<bool>("is Locked", (flow) =>
        { 
            bool valB = flow.GetValue<LobbyInfo_VSP>(aLobby).IsLocked;
            return valB;
        });
    }
}
