using Unity.Netcode;
using UnityEngine;
using Unity.VisualScripting;
using System;
using System.Collections.Generic;

public class NetworkVariableVSP : NetworkBehaviour
{
    //trigger when this Network Object spawn , require Component "Netcode :Network Object"
    private GameObject MacroNetcode = null;
    private NetcodeVSP MacroNetcodeScript = null;
    private string PlayerID_ = "null"; // for PlayerObject only for reconnect issue
    private MyNetString_VSP PlayerID__Net = new MyNetString_VSP();
    //Initial Network Variable value ... Network Variable should create before Network Object is spawned...
    //otherwise it will not update the value
    private NetworkVariable<Vector2> Vector2_Net = new NetworkVariable<Vector2>();
    private NetworkVariable<Vector3> Vector3_Net = new NetworkVariable<Vector3>();
    private NetworkVariable<Vector4> Vector4_Net = new NetworkVariable<Vector4>();
    private NetworkVariable<Quaternion> Quaternion_Net = new NetworkVariable<Quaternion>();
    private NetworkVariable<float> Float_Net = new NetworkVariable<float>();
    private NetworkVariable<bool> Bool_Net = new NetworkVariable<bool>();
    private NetworkVariable<int> Int_Net = new NetworkVariable<int>();
    private MyNetString_VSP String_Net = new MyNetString_VSP();
    private NetworkVariable<Ray> Ray_Net = new NetworkVariable<Ray>();
    private NetworkVariable<Ray2D> Ray2D_Net = new NetworkVariable<Ray2D>();
    private NetworkVariable<Color> Color_Net = new NetworkVariable<Color>();
    //private MyNetString Client_Chat_Net = new MyNetString();
    //...end Initial Values


    private void Awake()
    {
        MacroNetcode = GameObject.Find("Macro-Netcode");
        MacroNetcodeScript = MacroNetcode.GetComponent<NetcodeVSP>();
    }
    public override void OnNetworkSpawn()
    {
        Variables.Object(MacroNetcode).Set("Object Spawn", this.gameObject);
        MacroNetcodeScript.OnNetowrkObjectSpawn();
    }

    

    public override void OnNetworkDespawn()
    {
        Variables.Object(MacroNetcode).Set("Object Despawn", this.gameObject);
        MacroNetcodeScript.OnNetowrkObjectDeSpawn();
    }

    
    //..Create Variable
    private MyNetString_VSP CreateNetworkVariableString()
    {
        MyNetString_VSP variable_ = new MyNetString_VSP();
        return variable_;
    }
    private NetworkVariable<float> CreateNetworkVariableFloat()
    {
        NetworkVariable<float> variable_ = new NetworkVariable<float>();
        return variable_;
    }
    private NetworkVariable<int> CreateNetworkVariableInt()
    {
        NetworkVariable<int> variable_ = new NetworkVariable<int>();
        return variable_;
    }
    private NetworkVariable<bool> CreateNetworkVariableBool()
    {
        NetworkVariable<bool> variable_ = new NetworkVariable<bool>();
        return variable_;
    }
    private NetworkVariable<Vector2> CreateNetworkVariableVector2()
    {
        NetworkVariable<Vector2> variable_ = new NetworkVariable<Vector2>();
        return variable_;
    }
    private NetworkVariable<Vector3> CreateNetworkVariableVector3()
    {
        NetworkVariable<Vector3> variable_ = new NetworkVariable<Vector3>();

        return variable_;
    }
    private NetworkVariable<Vector4> CreateNetworkVariableVector4()
    {
        NetworkVariable<Vector4> variable_ = new NetworkVariable<Vector4>();
        return variable_;
    }
    private NetworkVariable<Quaternion> CreateNetworkVariableQuaternion()
    {
        NetworkVariable<Quaternion> variable_ = new NetworkVariable<Quaternion>();
        return variable_;
    }
    private NetworkVariable<Color> CreateNetworkVariableColor()
    {
        NetworkVariable<Color> variable_ = new NetworkVariable<Color>();
        return variable_;
    }
    private NetworkVariable<Ray> CreateNetworkVariableRay()
    {
        NetworkVariable<Ray> variable_ = new NetworkVariable<Ray>();
        return variable_;
    }
    private NetworkVariable<Ray2D> CreateNetworkVariableRay2D()
    {
        NetworkVariable<Ray2D> variable_ = new NetworkVariable<Ray2D>();
        return variable_;
    }
    

    //Create Network Variable
    //..
    public object CreateNetworkVariable(EnumVariableTypeNetworkVSP Type, object Variable)
    {
        string type_ = Type.ToString();
        if (type_ == "STRING")
        {
            Variable = CreateNetworkVariableString();
        }
        if (type_ == "FLOAT" || type_ == "SINGLE")
        {
            Variable = CreateNetworkVariableFloat();
        }
        if (type_ == "INT")
        {
            Variable = CreateNetworkVariableInt();
        }
        if (type_ == "BOOL")
        {
            Variable = CreateNetworkVariableBool();
        }
        if (type_ == "VECTOR2")
        {
            Variable = CreateNetworkVariableVector2();
        }
        if (type_ == "VECTOR3")
        {
            Variable = CreateNetworkVariableVector3();
        }
        if (type_ == "VECTOR4")
        {
            Variable = CreateNetworkVariableVector4();
        }
        if (type_ == "QUATERNION")
        {
            Variable = CreateNetworkVariableQuaternion();
        }
        if (type_ == "COLOR")
        {
            Variable = CreateNetworkVariableColor();
        }
        if (type_ == "RAY")
        {
            Variable = CreateNetworkVariableRay();
        }
        if (type_ == "RAY2D")
        {
            Variable = CreateNetworkVariableRay2D();
        }
        return Variable;
    }

    public object CreateNetworkVariableOnly(object Variable)
    {
        //-------------
        return null;
    }
    //..End Create Variable
    //..
   
    //..
    //..
    //..Update any type of Network Variable
    //..
    public void UpdateNetworkVariable(string name,object Variable)
    {
        try
        {
            var type_ = GetTypeOfValue(Variable).ToUpper();

            string type__ = "";
            //..3
            if (type_.Length >= 3)
            {
                type__ = type_.Substring(0, 3);
                if (type__ == "INT")
                {
                    UpdateNetworkVariableIntValueServerRpc(name, (int)Variable);
                    return;
                }
                if (type__ == "RAY")
                {
                    if (type_.Length < 5)
                    {
                        UpdateNetworkVariableRayValueServerRpc(name, (Ray)Variable);
                        return;
                    }
                }

            }

            //..4
            if (type_.Length >= 4)
            {

                type__ = type_.Substring(0, 4);
                if (type__ == "BOOL")
                {
                    UpdateNetworkVariableBoolValueServerRpc(name, (bool)Variable);
                    return;
                }
            }

            //..5
            if (type_.Length >= 5)
            {
                type__ = type_.Substring(0, 5);
                if (type__ == "FLOAT")
                {
                    UpdateNetworkVariableFloatValueServerRpc(name, (float)Variable);
                    return;
                }
                if (type__ == "COLOR")
                {
                    UpdateNetworkVariableColorValueServerRpc(name, (Color)Variable);
                    return;
                }
                if (type__ == "RAY2D")
                {
                    UpdateNetworkVariableRay2DValueServerRpc(name, (Ray2D)Variable);
                    return;
                }

            }

            //..6
            if (type_.Length >= 6)
            {

                type__ = type_.Substring(0, 6);
                if (type__ == "STRING")
                {
                    UpdateNetworkVariableStringValueServerRpc(name, (string)Variable);
                    return;
                }
                if (type__ == "SINGLE")
                {
                    UpdateNetworkVariableFloatValueServerRpc(name, (float)Variable);
                    return;
                }

            }

            //..7
            if (type_.Length >= 7)
            {
                type__ = type_.Substring(0, 7);
                if (type__ == "VECTOR2")
                {
                    UpdateNetworkVariableVector2ValueServerRpc(name, (Vector2)Variable);
                    return;
                }
                if (type__ == "VECTOR3")
                {
                    UpdateNetworkVariableVector3ValueServerRpc(name, (Vector3)Variable);
                    return;
                }
                if (type__ == "VECTOR4")
                {
                    UpdateNetworkVariableVector4ValueServerRpc(name, (Vector4)Variable);
                    return;
                }
            }

            //..10
            if (type_.Length >= 10)
            {
                type__ = type_.Substring(0, 10);

                if (type__ == "QUATERNION")
                {
                    UpdateNetworkVariableQuaternionValueServerRpc(name, (Quaternion)Variable);
                    return;
                }
            }

            //..11 MYNETSTRING
            if (type_.Length >= 11)
            {
                type__ = type_.Substring(0, 11);
                if (type__ == "MYNETSTRING")
                {
                    UpdateNetworkVariableStringValueServerRpc(name, (string)Variable);
                    return;
                }
            }
        }
        catch(Exception e)
        { 
            Debug.Log(e);
        }

    }
    //..END Update any type of Network Variable
    //..

    
    //..Update Value Server
    
    [ServerRpc]
    private void UpdateNetworkVariableStringValueServerRpc(string name, string value)
    {
        String_Net.Value = value;
        Variables.Object(gameObject).Set(name, String_Net);
    }
    [ServerRpc]
    private void UpdateNetworkVariableFloatValueServerRpc(string name, float value)
    {
        Float_Net.Value = value;
        ((NetworkVariable<float>)Variables.Object(this.gameObject).Get(name)).Value = Float_Net.Value;
    }

    
    [ServerRpc]
    private void UpdateNetworkVariableIntValueServerRpc(string name, int value)
    {
        Int_Net.Value = value;
        ((NetworkVariable<int>)Variables.Object(this.gameObject).Get(name)).Value = Int_Net.Value;
    }
    [ServerRpc]
    private void UpdateNetworkVariableBoolValueServerRpc(string name, bool value)
    {
        Bool_Net.Value = value;
        ((NetworkVariable<bool>)Variables.Object(this.gameObject).Get(name)).Value = Bool_Net.Value;
    }
    [ServerRpc]
    private void UpdateNetworkVariableVector2ValueServerRpc(string name, Vector2 value)
    {
        Vector2_Net.Value = value;
        ((NetworkVariable<Vector2>)Variables.Object(this.gameObject).Get(name)).Value = Vector2_Net.Value;
    }
    
    [ServerRpc]
    private void UpdateNetworkVariableVector3ValueServerRpc(string name, Vector3 value)
    {
        //var myvar = (NetworkVariable<Vector3>)Variables.Object(this.gameObject).Get(name);
        //myvar.Value = value;
        Vector3_Net.Value = value;
        ((NetworkVariable<Vector3>)Variables.Object(this.gameObject).Get(name)).Value = Vector3_Net.Value;
    }
    
    [ServerRpc]
    private void UpdateNetworkVariableVector4ValueServerRpc(string name, Vector4 value)
    {
        Vector4_Net.Value = value;
        ((NetworkVariable<Vector4>)Variables.Object(this.gameObject).Get(name)).Value = Vector4_Net.Value;
    }
    [ServerRpc]
    private void UpdateNetworkVariableQuaternionValueServerRpc(string name, Quaternion value)
    {
        Quaternion_Net.Value = value;
        ((NetworkVariable<Quaternion>)Variables.Object(this.gameObject).Get(name)).Value = Quaternion_Net.Value;
    }
    [ServerRpc]
    private void UpdateNetworkVariableColorValueServerRpc(string name, Color value)
    {
        Color_Net.Value = value;
        ((NetworkVariable<Color>)Variables.Object(this.gameObject).Get(name)).Value = Color_Net.Value;
    }
    
    [ServerRpc]
    private void UpdateNetworkVariableRayValueServerRpc(string name, Ray value)
    {
        //var myvar = (NetworkVariable<Ray>)Variables.Object(this.gameObject).Get(name);
        //myvar.Value = value;
        Ray_Net.Value = value;
        ((NetworkVariable<Ray>)Variables.Object(this.gameObject).Get(name)).Value = Ray_Net.Value;
    }
    [ServerRpc]
    private void UpdateNetworkVariableRay2DValueServerRpc(string name, Ray2D value)
    {
        Ray2D_Net.Value = value;
        ((NetworkVariable<Ray2D>)Variables.Object(this.gameObject).Get(name)).Value = Ray2D_Net.Value;
    }
    //..END Update Value Server


    //..String Fixed
    private string GetTypeOfNetworkVariable(object variable_)
    {
        var type_ = variable_.GetType().ToString();
        
        string value1 = "[";
        string value2 = "]";

        String St = type_;

        int firstSearch = St.IndexOf(value1);
        if (firstSearch < 0)
        {
            return St;
        }

        int pFrom = firstSearch + value1.Length;
        
        int pTo = St.LastIndexOf(value2);

        String result = St.Substring(pFrom, pTo - pFrom);

        string toBeSearched = ".";
        int ix = result.IndexOf(toBeSearched);

        if (ix != -1)
        {
            string finalType = result.Substring(ix + toBeSearched.Length);
            // do something here
            return finalType;
        }

        return "null";
    }
    private string GetTypeOfValue(object value_)
    {
        string type_ = value_.GetType().ToString();
        string toBeSearched = ".";
        int ix = type_.IndexOf(toBeSearched);

        if (ix != -1)
        {
            string code = type_.Substring(ix + toBeSearched.Length);
            // do something here
            return code;
        }
        return "null";
    }
    public string FixTypeVariable(string type_)
    {
        type_ = type_.ToUpper();

        string type__ = "STRING";
        //..3
        if (type_.Length >= 3)
        {
            type__ = type_.Substring(0, 3);
            if (type__ == "INT")
            {
                return type__;
            }
            if (type__ == "RAY")
            {
                return type__;
            }

        }

        //..4
        if (type_.Length >= 4)
        {

            type__ = type_.Substring(0, 4);
            if (type__ == "BOOL")
            {
                return type__;
            }
            
        }

        //..5
        if (type_.Length >= 5)
        {
            type__ = type_.Substring(0, 5);
            if (type__ == "FLOAT")
            {
                return type__;
            }
            if (type__ == "COLOR")
            {
                return type__;
            }
            if (type__ == "RAY2D")
            {
                return type__;
            }
                    }

        //..6
        if (type_.Length >= 6)
        {

            type__ = type_.Substring(0, 6);
            if (type__ == "STRING")
            {
                return type__;
            }
            if (type__ == "SINGLE")
            {
                return type__;
            }
            
        }

        //..7
        if (type_.Length >= 7)
        {
            type__ = type_.Substring(0, 7);
            if (type__ == "VECTOR2")
            {
                return type__;
            }
            if (type__ == "VECTOR3")
            {
                return type__;
            }
            if (type__ == "VECTOR4")
            {
                return type__;
            }
            
        }

        //..10
        if (type_.Length >= 10)
        {
            type__ = type_.Substring(0, 10);
            
            if (type__ == "QUATERNION")
            {
                return type__;
            }
        }

        //..11 MYNETSTRING
        if (type_.Length >= 11)
        {
            type__ = type_.Substring(0, 11);
            if (type__ == "MYNETSTRING")
            {
                return type__;
            }
        }

        

        return "null";
    }
    //..END Get TypeFixed

    public object GetValueVariableAllType(string name)
    {
        try 
        {
            var currentVar = Variables.Object(gameObject).Get(name);

            var type_ = GetTypeOfNetworkVariable(currentVar).ToUpper();

            string type__ = "";
            //..3
            if (type_.Length >= 3)
            {
                type__ = type_.Substring(0, 3);
                if (type__ == "INT")
                {
                    return ((NetworkVariable<int>)currentVar).Value;
                }
                if (type__ == "RAY")
                {
                    if (type_.Length < 5)
                    {
                        return ((NetworkVariable<Ray>)currentVar).Value;
                    }
                }
            }
            //..4
            if (type_.Length >= 4)
            {

                type__ = type_.Substring(0, 4);
                if (type__ == "BOOL")
                {
                    return ((NetworkVariable<bool>)currentVar).Value;
                }

            }

            //..5
            if (type_.Length >= 5)
            {
                type__ = type_.Substring(0, 5);
                if (type__ == "FLOAT")
                {
                    return ((NetworkVariable<float>)currentVar).Value;
                }
                if (type__ == "COLOR")
                {
                    return ((NetworkVariable<Color>)currentVar).Value;
                }
                if (type__ == "RAY2D")
                {
                    return ((NetworkVariable<Ray2D>)currentVar).Value;
                }

            }

            //..6
            if (type_.Length >= 6)
            {

                type__ = type_.Substring(0, 6);
                if (type__ == "STRING")
                {
                    return ((MyNetString_VSP)currentVar).Value;
                }
                if (type__ == "SINGLE")
                {
                    return ((NetworkVariable<float>)currentVar).Value;
                }

            }

            //..7
            if (type_.Length >= 7)
            {
                type__ = type_.Substring(0, 7);
                if (type__ == "VECTOR2")
                {
                    return ((NetworkVariable<Vector2>)currentVar).Value;
                }
                if (type__ == "VECTOR3")
                {
                    return ((NetworkVariable<Vector3>)currentVar).Value;
                }
                if (type__ == "VECTOR4")
                {
                    return ((NetworkVariable<Vector4>)currentVar).Value;
                }
            }

            //..10
            if (type_.Length >= 10)
            {
                type__ = type_.Substring(0, 10);

                if (type__ == "QUATERNION")
                {
                    return ((NetworkVariable<Quaternion>)currentVar).Value;
                }
            }

            //..11 MYNETSTRING
            if (type_.Length >= 11)
            {
                type__ = type_.Substring(0, 11);
                if (type__ == "MYNETSTRING")
                {
                    return ((MyNetString_VSP)currentVar).Value;
                }
            }

            return "null";
        }
        catch (Exception e)
        {
            Debug.Log(e);
            return "null";
        }
        
    }
    //.. fix TYPE


    public ulong GetOwnerClientID()
    {
        return this.OwnerClientId;
    }


    //reconnect issue with Lobby & Relay
    

    [ServerRpc]
    private void UpdateNetworkPlayerIDServerRpc()
    {
        PlayerID__Net.Value = PlayerID_;
    }


    //..
    //..
    //Set Message To Client From Server
    //..
    //..
    public void ServerSendMessageToAClient(string msg_, ulong clientID_)
    {

        ClientRpcParams clientRpcParams = new ClientRpcParams
        {
            Send = new ClientRpcSendParams
            {
                TargetClientIds = new ulong[] { clientID_ }
            }
        };
        
        ServerSendMessageToAClientRpc(msg_, clientRpcParams);
       
    }

    public void ServerSendMessageToMultiClients(string msg_, List<ulong> ListClientIDs_)
    {

        ClientRpcParams clientRpcParams = new ClientRpcParams
        {
            Send = new ClientRpcSendParams
            {
                TargetClientIds = ListClientIDs_
            }
        };

        ServerSendMessageToAClientRpc(msg_, clientRpcParams);

    }
    [ClientRpc]
    private void ServerSendMessageToAClientRpc(string msg_, ClientRpcParams clientRpcParams = default)
    {
        if (IsOwner) return; //if this is a Client Object from Server. It will do nothing here
        
        CustomEvent.Trigger(MacroNetcode, "MessagefromServer_Success", msg_);
    }
    

    //..Message + Value
    public void ServerSendMessageValueToAClient(string msg_, ulong clientID_, object Variable)
    {

        //ulong id_ = ClientObjectNetVarVSP_.OwnerClientId;
        ClientRpcParams clientRpcParams = new ClientRpcParams
        {
            Send = new ClientRpcSendParams
            {
                TargetClientIds = new ulong[] { clientID_ }
            }
        };

        var type_ = GetTypeOfValue(Variable).ToUpper();

        string type__ = "";
        //..3
        if (type_.Length >= 3)
        {
            type__ = type_.Substring(0, 3);
            if (type__ == "INT")
            {
                ServerSendMessageValueIntToAClientRpc(msg_, (int)Variable, clientRpcParams);
                return;
            }
            if (type__ == "RAY")
            {
                if (type_.Length < 5)
                {
                    ServerSendMessageValueRayToAClientRpc(msg_, (Ray)Variable, clientRpcParams);
                    return;
                }
            }

        }

        //..4
        if (type_.Length >= 4)
        {

            type__ = type_.Substring(0, 4);
            if (type__ == "BOOL")
            {
                ServerSendMessageValueBoolToAClientRpc(msg_, (bool)Variable, clientRpcParams);
                return;
            }
        }

        //..5
        if (type_.Length >= 5)
        {
            type__ = type_.Substring(0, 5);
            if (type__ == "FLOAT")
            {
                ServerSendMessageValueFloatToAClientRpc(msg_, (float)Variable, clientRpcParams);
                return;
            }
            if (type__ == "COLOR")
            {
                ServerSendMessageValueColorToAClientRpc(msg_, (Color)Variable, clientRpcParams);
                return;
            }
            if (type__ == "RAY2D")
            {
                ServerSendMessageValueRay2DToAClientRpc(msg_, (Ray2D)Variable, clientRpcParams);
                return;
            }

        }

        //..6
        if (type_.Length >= 6)
        {

            type__ = type_.Substring(0, 6);
            if (type__ == "STRING")
            {
                ServerSendMessageValueStringToAClientRpc(msg_, (string)Variable, clientRpcParams);
                return;
            }
            if (type__ == "SINGLE")
            {
                ServerSendMessageValueFloatToAClientRpc(msg_, (float)Variable, clientRpcParams);
                return;
            }
            
        }


        //..7
        if (type_.Length >= 7)
        {
            type__ = type_.Substring(0, 7);
            if (type__ == "VECTOR2")
            {
                ServerSendMessageValueVector2ToAClientRpc(msg_, (Vector2)Variable, clientRpcParams);
                return;
            }
            if (type__ == "VECTOR3")
            {
                ServerSendMessageValueVector3ToAClientRpc(msg_, (Vector3)Variable, clientRpcParams);
                return;
            }
            if (type__ == "VECTOR4")
            {
                ServerSendMessageValueVector4ToAClientRpc(msg_, (Vector4)Variable, clientRpcParams);
                return;
            }
        }

        //..10
        if (type_.Length >= 10)
        {
            type__ = type_.Substring(0, 10);

            if (type__ == "QUATERNION")
            {
                ServerSendMessageValueQUATERNIONToAClientRpc(msg_, (Quaternion)Variable, clientRpcParams);
                return;
            }
        }


    }

    public void ServerSendMessageValueToMultiClient(string msg_, List<ulong> clientIDs_, object Variable)
    {

        ClientRpcParams clientRpcParams = new ClientRpcParams
        {
            Send = new ClientRpcSendParams
            {
                TargetClientIds = clientIDs_
            }
        };

        var type_ = GetTypeOfValue(Variable).ToUpper();

        string type__ = "";
        //..3
        if (type_.Length >= 3)
        {
            type__ = type_.Substring(0, 3);
            if (type__ == "INT")
            {
                ServerSendMessageValueIntToAClientRpc(msg_, (int)Variable, clientRpcParams);
                return;
            }
            if (type__ == "RAY")
            {
                if (type_.Length < 5)
                {
                    ServerSendMessageValueRayToAClientRpc(msg_, (Ray)Variable, clientRpcParams);
                    return;
                }
            }

        }

        //..4
        if (type_.Length >= 4)
        {

            type__ = type_.Substring(0, 4);
            if (type__ == "BOOL")
            {
                ServerSendMessageValueBoolToAClientRpc(msg_, (bool)Variable, clientRpcParams);
                return;
            }
        }

        //..5
        if (type_.Length >= 5)
        {
            type__ = type_.Substring(0, 5);
            if (type__ == "FLOAT")
            {
                ServerSendMessageValueFloatToAClientRpc(msg_, (float)Variable, clientRpcParams);
                return;
            }
            if (type__ == "COLOR")
            {
                ServerSendMessageValueColorToAClientRpc(msg_, (Color)Variable, clientRpcParams);
                return;
            }
            if (type__ == "RAY2D")
            {
                ServerSendMessageValueRay2DToAClientRpc(msg_, (Ray2D)Variable, clientRpcParams);
                return;
            }

        }

        //..6
        if (type_.Length >= 6)
        {

            type__ = type_.Substring(0, 6);
            if (type__ == "STRING")
            {
                ServerSendMessageValueStringToAClientRpc(msg_, (string)Variable, clientRpcParams);
                return;
            }
            if (type__ == "SINGLE")
            {
                ServerSendMessageValueFloatToAClientRpc(msg_, (float)Variable, clientRpcParams);
                return;
            }
        }

        //..7
        if (type_.Length >= 7)
        {
            type__ = type_.Substring(0, 7);
            if (type__ == "VECTOR2")
            {
                ServerSendMessageValueVector2ToAClientRpc(msg_, (Vector2)Variable, clientRpcParams);
                return;
            }
            if (type__ == "VECTOR3")
            {
                ServerSendMessageValueVector3ToAClientRpc(msg_, (Vector3)Variable, clientRpcParams);
                return;
            }
            if (type__ == "VECTOR4")
            {
                ServerSendMessageValueVector4ToAClientRpc(msg_, (Vector4)Variable, clientRpcParams);
                return;
            }
        }

        //..10
        if (type_.Length >= 10)
        {
            type__ = type_.Substring(0, 10);

            if (type__ == "QUATERNION")
            {
                ServerSendMessageValueQUATERNIONToAClientRpc(msg_, (Quaternion)Variable, clientRpcParams);
                return;
            }
        }


    }

    [ClientRpc]
    private void ServerSendMessageValueIntToAClientRpc(string msg_, int value_, ClientRpcParams clientRpcParams = default)
    {
        if (IsOwner) return; //if this is a Client Object from Server. It will do nothing here

        CustomEvent.Trigger(MacroNetcode, "ValueMessagefromServer_Success", msg_, value_);
    }

    [ClientRpc]
    private void ServerSendMessageValueRayToAClientRpc(string msg_, Ray value_, ClientRpcParams clientRpcParams = default)
    {
        if (IsOwner) return; //if this is a Client Object from Server. It will do nothing here

        CustomEvent.Trigger(MacroNetcode, "ValueMessagefromServer_Success", msg_, value_);
    }

    [ClientRpc]
    private void ServerSendMessageValueBoolToAClientRpc(string msg_, bool value_, ClientRpcParams clientRpcParams = default)
    {
        if (IsOwner) return; //if this is a Client Object from Server. It will do nothing here

        CustomEvent.Trigger(MacroNetcode, "ValueMessagefromServer_Success", msg_, value_);
    }

    [ClientRpc]
    private void ServerSendMessageValueFloatToAClientRpc(string msg_, float value_, ClientRpcParams clientRpcParams = default)
    {
        if (IsOwner) return; //if this is a Client Object from Server. It will do nothing here

        CustomEvent.Trigger(MacroNetcode, "ValueMessagefromServer_Success", msg_, value_);
    }

    [ClientRpc]
    private void ServerSendMessageValueColorToAClientRpc(string msg_, Color value_, ClientRpcParams clientRpcParams = default)
    {
        if (IsOwner) return; //if this is a Client Object from Server. It will do nothing here

        CustomEvent.Trigger(MacroNetcode, "ValueMessagefromServer_Success", msg_, value_);
    }

    [ClientRpc]
    private void ServerSendMessageValueRay2DToAClientRpc(string msg_, Ray2D value_, ClientRpcParams clientRpcParams = default)
    {
        if (IsOwner) return; //if this is a Client Object from Server. It will do nothing here

        CustomEvent.Trigger(MacroNetcode, "ValueMessagefromServer_Success", msg_, value_);
    }

    [ClientRpc]
    private void ServerSendMessageValueStringToAClientRpc(string msg_, string value_, ClientRpcParams clientRpcParams = default)
    {
        if (IsOwner) return; //if this is a Client Object from Server. It will do nothing here

        CustomEvent.Trigger(MacroNetcode, "ValueMessagefromServer_Success", msg_, value_);
    }

    [ClientRpc]
    private void ServerSendMessageValueVector2ToAClientRpc(string msg_, Vector2 value_, ClientRpcParams clientRpcParams = default)
    {
        if (IsOwner) return; //if this is a Client Object from Server. It will do nothing here

        CustomEvent.Trigger(MacroNetcode, "ValueMessagefromServer_Success", msg_, value_);
    }

    [ClientRpc]
    private void ServerSendMessageValueVector3ToAClientRpc(string msg_, Vector3 value_, ClientRpcParams clientRpcParams = default)
    {
        if (IsOwner) return; //if this is a Client Object from Server. It will do nothing here

        CustomEvent.Trigger(MacroNetcode, "ValueMessagefromServer_Success", msg_, value_);
    }

    [ClientRpc]
    private void ServerSendMessageValueVector4ToAClientRpc(string msg_, Vector4 value_, ClientRpcParams clientRpcParams = default)
    {
        if (IsOwner) return; //if this is a Client Object from Server. It will do nothing here

        CustomEvent.Trigger(MacroNetcode, "ValueMessagefromServer_Success", msg_, value_);
    }


    [ClientRpc]
    private void ServerSendMessageValueQUATERNIONToAClientRpc(string msg_, Quaternion value_, ClientRpcParams clientRpcParams = default)
    {
        if (IsOwner) return; //if this is a Client Object from Server. It will do nothing here

        CustomEvent.Trigger(MacroNetcode, "ValueMessagefromServer_Success", msg_, value_);
    }


    //..
    //..
    //Set Message From Client to Server
    //..
    //..
    public void ClientSendMessageToAServer(string msg_)
    {

        ClientSendMessageToAServerRpc(msg_);
    }

    [ServerRpc]
    private void ClientSendMessageToAServerRpc(string msg_)
    {
        CustomEvent.Trigger(MacroNetcode, "ClientSendMessageToAServer_Success", msg_);
    }

    public void ClientSendMessageValueToServer(string msg_, object Variable)
    {
        var type_ = GetTypeOfValue(Variable).ToUpper();

        string type__ = "";
        //..3
        if (type_.Length >= 3)
        {
            type__ = type_.Substring(0, 3);
            if (type__ == "INT")
            {
                ClientSendMessageValueIntToServerRpc(msg_, (int)Variable);
                return;
            }
            if (type__ == "RAY")
            {
                if (type_.Length < 5)
                {
                    ClientSendMessageValueRayToServerRpc(msg_, (Ray)Variable);
                    return;
                }
            }

        }

        //..4
        if (type_.Length >= 4)
        {

            type__ = type_.Substring(0, 4);
            if (type__ == "BOOL")
            {
                ClientSendMessageValueBoolToServerRpc(msg_, (bool)Variable);
                return;
            }
        }

        //..5
        if (type_.Length >= 5)
        {
            type__ = type_.Substring(0, 5);
            if (type__ == "FLOAT")
            {
                ClientSendMessageValueFloatToServerRpc(msg_, (float)Variable);
                return;
            }
            if (type__ == "COLOR")
            {
                ClientSendMessageValueColorToServerRpc(msg_, (Color)Variable);
                return;
            }
            if (type__ == "RAY2D")
            {
                ClientSendMessageValueRay2DToServerRpc(msg_, (Ray2D)Variable);
                return;
            }

        }

        //..6
        if (type_.Length >= 6)
        {

            type__ = type_.Substring(0, 6);
            if (type__ == "STRING")
            {
                ClientSendMessageValueStringToServerRpc(msg_, (string)Variable);
                return;
            }
            if (type__ == "SINGLE")
            {
                ClientSendMessageValueFloatToServerRpc(msg_, (float)Variable);
                return;
            }
        }
        
        //..7
        if (type_.Length >= 7)
        {
            type__ = type_.Substring(0, 7);
            if (type__ == "VECTOR2")
            {
                ClientSendMessageValueVector2ToServerRpc(msg_, (Vector2)Variable);
                return;
            }
            if (type__ == "VECTOR3")
            {
                ClientSendMessageValueVector3ToServerRpc(msg_, (Vector3)Variable);
                return;
            }
            if (type__ == "VECTOR4")
            {
                ClientSendMessageValueVector4ToServerRpc(msg_, (Vector4)Variable);
                return;
            }
        }

        //..10
        if (type_.Length >= 10)
        {
            type__ = type_.Substring(0, 10);

            if (type__ == "QUATERNION")
            {
                ClientSendMessageValueQuaternionToServerRpc(msg_, (Quaternion)Variable);
                return;
            }
        }

    }

    [ServerRpc]
    private void ClientSendMessageValueIntToServerRpc(string msg_,int value_)
    {
        CustomEvent.Trigger(MacroNetcode, "ClientSendMessageValueToAServer_Success", msg_, value_);
    }

    [ServerRpc]
    private void ClientSendMessageValueRayToServerRpc(string msg_, Ray value_)
    {
        CustomEvent.Trigger(MacroNetcode, "ClientSendMessageValueToAServer_Success", msg_, value_);
    }

    [ServerRpc]
    private void ClientSendMessageValueBoolToServerRpc(string msg_, bool value_)
    {
        CustomEvent.Trigger(MacroNetcode, "ClientSendMessageValueToAServer_Success", msg_, value_);
    }

    [ServerRpc]
    private void ClientSendMessageValueFloatToServerRpc(string msg_, float value_)
    {
        CustomEvent.Trigger(MacroNetcode, "ClientSendMessageValueToAServer_Success", msg_, value_);
    }

    [ServerRpc]
    private void ClientSendMessageValueColorToServerRpc(string msg_, Color value_)
    {
        CustomEvent.Trigger(MacroNetcode, "ClientSendMessageValueToAServer_Success", msg_, value_);
    }

    [ServerRpc]
    private void ClientSendMessageValueRay2DToServerRpc(string msg_, Ray2D value_)
    {
        CustomEvent.Trigger(MacroNetcode, "ClientSendMessageValueToAServer_Success", msg_, value_);
    }

    [ServerRpc]
    private void ClientSendMessageValueStringToServerRpc(string msg_, string value_)
    {
        CustomEvent.Trigger(MacroNetcode, "ClientSendMessageValueToAServer_Success", msg_, value_);
    }

    [ServerRpc]
    private void ClientSendMessageValueVector2ToServerRpc(string msg_, Vector2 value_)
    {
        CustomEvent.Trigger(MacroNetcode, "ClientSendMessageValueToAServer_Success", msg_, value_);
    }
    [ServerRpc]
    private void ClientSendMessageValueVector3ToServerRpc(string msg_, Vector3 value_)
    {
        CustomEvent.Trigger(MacroNetcode, "ClientSendMessageValueToAServer_Success", msg_, value_);
    }
    [ServerRpc]
    private void ClientSendMessageValueVector4ToServerRpc(string msg_, Vector4 value_)
    {
        CustomEvent.Trigger(MacroNetcode, "ClientSendMessageValueToAServer_Success", msg_, value_);
    }
    [ServerRpc]
    private void ClientSendMessageValueQuaternionToServerRpc(string msg_, Quaternion value_)
    {
        CustomEvent.Trigger(MacroNetcode, "ClientSendMessageValueToAServer_Success", msg_, value_);
    }

    //..
    //.. END client send Message to Server

    public void ConfirmCreateVariableToServer(ulong ClientID_, string name_, string type_)
    {
        ConfirmCreateVariableTypeToServerRpc(ClientID_, name_, type_);

       
    }
    [ServerRpc]
    private void ConfirmCreateVariableTypeToServerRpc(ulong id_, string name_, string type_)
    {
        CustomEvent.Trigger(MacroNetcode, "ConfirmCreateVariableToServer_Success", id_, name_, type_);
    }


    //Steam: Update Client
    public void SteamUpdateClientPrepare(string clientId, string clientSteamId)
    {
        SteamUpdateClientToServerRpc(clientId, clientSteamId);
    }

    [ServerRpc]
    private void SteamUpdateClientToServerRpc(string clientId, string clientSteamId)
    {
        CustomEvent.Trigger(MacroNetcode, "SteamUpdateClient_Trigger", clientId, clientSteamId);
    }

}

