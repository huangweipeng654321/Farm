
using UnityEngine;

public class ServerNetworkSampleVSP : MonoBehaviour
{
    public static ServerNetworkSampleVSP Instance { get; private set; } = null;
    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
        }
        else
        {
            Destroy(gameObject);
            return;
        }

        DontDestroyOnLoad(gameObject);

    }
}
