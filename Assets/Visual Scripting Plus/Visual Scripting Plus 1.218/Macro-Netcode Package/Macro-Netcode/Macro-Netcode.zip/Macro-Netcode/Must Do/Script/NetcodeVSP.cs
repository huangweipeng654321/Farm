using System;
using System.Collections;
using System.Collections.Generic;
using Unity.Netcode;
using Unity.Netcode.Transports.UTP;
using Unity.VisualScripting;
using UnityEngine;

public class NetcodeVSP : MonoBehaviour
{
    private UnityTransport _transport;
    private GameObject MacroNetcode_VSP;
    public static NetcodeVSP Singleton { get; internal set; }
    private bool isPlayerSpawned = false;

    public ulong ConvertIntToULongVSP(ulong value_)
    {
        return value_;
    }


    public void SetIsPlayerSpawned(bool value_)
    {
        isPlayerSpawned = value_;
    }
    public bool GetIsPlayerSpawned()
    {
        return isPlayerSpawned;
    }
    public void OnNetowrkObjectSpawn()
    {
        CustomEvent.Trigger(MacroNetcode_VSP, "NetcodeOnNetworkSpawnTrigger");
    }
    public void OnNetowrkObjectDeSpawn()
    {
        CustomEvent.Trigger(MacroNetcode_VSP, "NetcodeOnNetworkDeSpawnTrigger");
    }
    public bool isServer()
    {
        return NetworkManager.Singleton.IsServer;
    }
    public bool isClient()
    {
        return NetworkManager.Singleton.IsClient;
    }
    public bool isHost()
    {
        return NetworkManager.Singleton.IsHost;
    }

    public void StartHost()
    {
        NetworkManager.Singleton.StartHost();
    }
    public void StartClient()
    {
        NetworkManager.Singleton.StartClient();
    }
    public void StartServer()
    {
        
        NetworkManager.Singleton.StartServer();
        
    }
    private void OnServerStartedCallback()
    {
        CustomEvent.Trigger(MacroNetcode_VSP, "NetcodeOnServerStarted_Trigger");
    }
    private void OnClientStartedCallback()
    {
        CustomEvent.Trigger(MacroNetcode_VSP, "NetcodeOnClientStarted_Trigger");
    }

    
    public string NameOfTransport()
    {
        return NetworkManager.Singleton.NetworkConfig.NetworkTransport.GetType().Name;
    }

    public NetworkObject GetLocalPlayerObject()
    {
        return NetworkManager.Singleton.SpawnManager.GetLocalPlayerObject();
    }

    public List<ulong> ConnectedClientsIds()
    {
        return (List<ulong>)NetworkManager.Singleton.ConnectedClientsIds;
    }

    public NetworkObject GetPlayerNetworkObjectFromClientID(ulong uid)
    {
        return NetworkManager.Singleton.SpawnManager.GetPlayerNetworkObject(uid);
        
    }
    public ulong GetServerClientID()
    {
        return NetworkManager.ServerClientId;
    }

    //..On Created Variable
    public object OnCreateNetworkVariable(object var)
    {
        return var;
    }

    public void Shutdown()
    {
        NetworkManager.Singleton.Shutdown();
    }

    public void DisconnectPlayer(NetworkObject player)
    {
        // Server only. If a client invokes this method, it will throw an exception.
        NetworkManager.Singleton.DisconnectClient(player.OwnerClientId);
    }

    public void DisconnectClientID(ulong ClientID)
    {
        // Server only. If a client invokes this method, it will throw an exception.
        NetworkManager.Singleton.DisconnectClient(ClientID);
    }
    public List<ClientList_VSP> GetConnectedClientIDs()
    {
        List<ClientList_VSP> NewList_ = new List<ClientList_VSP>();
        ClientList_VSP NewClient = new ClientList_VSP();
        foreach (ulong clientID in ConnectedClientsIds())
        {
            NewClient.ClientID = clientID;
            NewClient.PlayerObject = NetworkManager.Singleton.SpawnManager.GetPlayerNetworkObject(clientID).gameObject;
            NewList_.Add(NewClient);

        }
        return NewList_;
    }

    

   
    public void SetParentForNetworkObject(NetworkObject NetObject,Transform Parent, float Time_)
    {
        var check = Parent.gameObject.GetComponent<NetworkObject>();
        if (check == null)
        {
            Debug.Log("Parent Object must have component [Network Object] !");
        }
        else
        {
            if (Time_ <= 0)
            {
                NetObject.TrySetParent(Parent);
            }
            else
            {
                StartCoroutine(SetParentWithTimer(NetObject, Parent , Time_));
            }
            
        }
        
    }
    IEnumerator SetParentWithTimer(NetworkObject NetObject, Transform Parent,float Timer_)
    {
        yield return new WaitForSeconds(Timer_);
        NetObject.TrySetParent(Parent);
    }

    public GameObject GetPlayerPrefab()
    {
        var go = NetworkManager.Singleton.NetworkConfig.PlayerPrefab;
        return go;
    }

    //..
    //Client connect

    
    
    private void Start()
    {
        if (Singleton != this)
        {
            return; // so things don't get even more broken if this is a duplicate >:(
        }

        if (NetworkManager.Singleton == null)
        {
            // Can't listen to something that doesn't exist >:(
            throw new Exception($"There is no {nameof(NetworkManager)} for the {nameof(ConnectionNotificationManager_VSP)} to do stuff with! " +
                $"Please add a {nameof(NetworkManager)} to the scene.");
        }

        NetworkManager.Singleton.OnClientConnectedCallback += OnClientConnectedCallback;
        NetworkManager.Singleton.OnClientDisconnectCallback += OnClientDisconnectCallback;
        NetworkManager.Singleton.OnServerStarted += OnServerStartedCallback;
        NetworkManager.Singleton.OnClientStarted += OnClientStartedCallback;
        myNetworkManager = NetworkManager.Singleton;

    }
    private void OnDestroy()
    {
        if (NetworkManager.Singleton != null)
        {
            NetworkManager.Singleton.OnClientConnectedCallback -= OnClientConnectedCallback;
            NetworkManager.Singleton.OnClientDisconnectCallback -= OnClientDisconnectCallback;
            NetworkManager.Singleton.OnServerStarted -= OnServerStartedCallback;
            NetworkManager.Singleton.OnClientStarted -= OnServerStartedCallback;
        }
    }



    private void OnClientConnectedCallback(ulong clientId)
    {
        CustomEvent.Trigger(MacroNetcode_VSP, "NetcodeOnClientConnectedTrigger", clientId);
    }

    private void OnClientDisconnectCallback(ulong clientId)
    {
        CustomEvent.Trigger(MacroNetcode_VSP, "NetcodeOnClientDisConnectedTrigger", clientId);
    }
    //END Client connect
    //..

    public void CreateNormalNetworkObject(GameObject go)
    {
        go.GetComponent<NetworkObject>().Spawn();
    }

    public void AddObjectToNetworkPrefabs(GameObject object_)
    {
        NetworkPrefab netprefab = new NetworkPrefab();
        netprefab.Prefab = object_;
        netprefab.Override = NetworkPrefabOverride.Hash;
        var prefabs_ = NetworkManager.Singleton.NetworkConfig.Prefabs;
        var firstList = prefabs_.NetworkPrefabsLists[0];
        if (firstList.Contains(netprefab))
        {
            return;
        }
        else
        {
            firstList.Add(netprefab);
        }
    }

    //awake
    private void Awake()
    {
        _transport = FindFirstObjectByType<UnityTransport>();
        if (Singleton != null)
        {
            throw new Exception($"Detected more than one instance of {nameof(ConnectionNotificationManager_VSP)}! " + $"Do you have more than one component attached to a {nameof(GameObject)}");
        }
        Singleton = this;
        MacroNetcode_VSP = FindFirstObjectByType<NetcodeVSP>().gameObject;

    }

    NetworkManager myNetworkManager;
    public int GetPing()
    {
        int myping = 999;
        try
        {
            //myping = (int)((NetworkManager.Singleton.LocalTime.Time - NetworkManager.Singleton.ServerTime.Time)*1000);
            myping = (int)((myNetworkManager.LocalTime.Time - myNetworkManager.ServerTime.Time) * 1000);
        }
        catch(Exception e) 
        {
            Debug.Log(e);
        }

        return myping;

    }


    
}

