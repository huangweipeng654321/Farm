public enum Relay_Region_VSP
{
    None,
    US_East,
    US_Central,
    US_West,
    North_America,
    South_America,
    Europe_Central,
    Europe_North,
    Europe_West,
    Australia,
    Asia_South,
    Asia_SouthEast,
    Asia_NorthEast
};
